// Shared custom types — no namespace, imported directly by name
type Amount    : Decimal(10,2);
type ShortText : String(100);
type LongText  : String(5000);
