namespace cap.demo;

using { managed, cuid } from '@sap/cds/common';

// ── Core entities used across all topics ─────────────────────────────────────

entity Books {
  key ID     : Integer;
      title  : String(100) @mandatory;
      price  : Decimal(10,2) @assert.range: [0, 9999];
      stock  : Integer default 0;
      author : Association to Authors;
}

entity Authors {
  key ID   : Integer;
      name : String(100);
      books : Association to many Books on books.author = $self;
}
  entity Orders2 {
    key ID    : Integer;
        total : Decimal(10,2);
        items : Composition of many OrderItems on items.order = $self;
  }
  entity OrderItems {
    key order : Association to Orders2;
    key pos   : Integer;
        product : String(80);
        qty     : Integer;
  }
