using cap.demo as db from '../db/schema';

service CatalogService {
  entity Books   as projection on db.Books;
  entity Authors as projection on db.Authors;
  entity Orders2 as projection on db.Orders2;
  entity OrderItems as projection on db.OrderItems;
}
