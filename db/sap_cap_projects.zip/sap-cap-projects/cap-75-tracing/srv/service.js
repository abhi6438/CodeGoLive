const cds = require('@sap/cds');
module.exports = cds.service.impl(async function () {
  this.on('READ', 'Books', async (req) => {
    // In production: trace spans added via OTEL SDK
    const spanId = req.headers?.['x-b3-spanid'] || 'local-span';
    const db = await cds.connect.to('db');
    const result = await db.run(req.query);
    result.forEach(b => b._spanId = spanId);
    return result;
  });
});