namespace cap.demo;

using { managed, cuid } from '@sap/cds/common';

// ── Core entities used across all topics ─────────────────────────────────────

entity Books {
  key ID     : Integer;
      title  : String(100) @mandatory;
      price  : Decimal(10,2) @assert.range: [0, 9999];
      stock  : Integer default 0;
      author : Association to Authors;
}

entity Authors {
  key ID   : Integer;
      name : String(100);
      books : Association to many Books on books.author = $self;
}
  aspect Auditable {
    createdBy  : String(100);
    modifiedBy : String(100);
  }
  entity Reviews : Auditable {
    key ID    : Integer;
        text  : String(500);
        stars : Integer;
  }
