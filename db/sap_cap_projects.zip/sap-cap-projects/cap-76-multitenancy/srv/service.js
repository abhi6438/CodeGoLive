const cds = require('@sap/cds');
module.exports = cds.service.impl(async function () {
  this.on('READ', 'Books', async (req) => {
    const tenant = req.user?.tenant || 'default';
    console.log(`[MT] Reading Books for tenant: ${tenant}`);
    const db = await cds.connect.to('db');
    return db.run(req.query);
  });
});