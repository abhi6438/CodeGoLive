const cds = require('@sap/cds');
module.exports = cds.service.impl(async function () {
  this.on('archiveOldBooks', (req) => {
    if (!req.user.is('Editor'))
      return req.reject(403, 'Editors only');
    return 'Archive job queued';
  });
});