using cap.demo as db from '../db/schema';

service CatalogService {
  @requires: 'Viewer'
  entity Books   as projection on db.Books;
  entity Authors as projection on db.Authors;

  @requires: 'Editor'
  action archiveOldBooks() returns String;
}
