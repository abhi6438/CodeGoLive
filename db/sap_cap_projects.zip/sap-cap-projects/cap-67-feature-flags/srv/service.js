const cds = require('@sap/cds');
// Simple in-memory feature flag store (replace with FF service in production)
const FLAGS = { 'new-pricing': true, 'beta-search': false };

module.exports = cds.service.impl(async function () {
  this.on('isFeatureEnabled', (req) => {
    return FLAGS[req.data.flag] ?? false;
  });

  this.on('READ', 'Books', async (req) => {
    const db = await cds.connect.to('db');
    const books = await db.run(req.query);
    if (FLAGS['new-pricing']) {
      books.forEach(b => b._discountedPrice = +(b.price * 0.9).toFixed(2));
    }
    return books;
  });
});