namespace cap.demo;

using { managed } from '@sap/cds/common';
using cap.common from './common-types';

entity Books {
  key ID     : Integer;
      title  : String(100) @mandatory;
      price  : Decimal(10,2) @assert.range: [0, 9999];
      stock  : Integer default 0;
      author : Association to Authors;
}

entity Authors {
  key ID   : Integer;
      name : String(100);
      books : Association to many Books on books.author = $self;
}

// Demonstrates importing types from a separate CDS file
entity Journals {
  key ID    : Integer;
      title : cap.common.ShortText;
      body  : cap.common.LongText;
      value : cap.common.Amount;
}
