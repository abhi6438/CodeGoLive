const cds = require('@sap/cds');
module.exports = cds.service.impl(async function () {
  this.before('CREATE', 'Books', (req) => {
    // Sanitise string inputs
    if (req.data.title)
      req.data.title = req.data.title.replace(/<[^>]*>/g, '').trim();
    if (req.data.price !== undefined && isNaN(Number(req.data.price)))
      return req.reject(400, 'Price must be a number');
  });
});