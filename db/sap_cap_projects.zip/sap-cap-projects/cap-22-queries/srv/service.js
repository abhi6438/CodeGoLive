const cds = require('@sap/cds');
module.exports = cds.service.impl(async function () {
  const { Books } = this.entities;

  // Custom handler demonstrating CQL
  this.on('READ', 'Books', async (req) => {
    const db = await cds.connect.to('db');
    return await db.run(
      SELECT.from(Books)
        .where({ price: { '<': 50 } })
        .orderBy('price asc')
    );
  });
});