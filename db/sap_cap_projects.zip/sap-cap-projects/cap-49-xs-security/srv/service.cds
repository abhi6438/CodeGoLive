using cap.demo as db from '../db/schema';

service CatalogService {
  @requires: 'authenticated-user'
  entity Books   as projection on db.Books;
  entity Authors as projection on db.Authors;
}
