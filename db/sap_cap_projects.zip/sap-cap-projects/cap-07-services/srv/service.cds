using cap.demo as db from '../db/schema';

service CatalogService {
  @cds.redirection.target
  entity Books   as projection on db.Books;
  entity Authors as projection on db.Authors;

  // Read-only flat view of Books (no back-association ambiguity)
  @readonly
  entity BookList as select from db.Books { ID, title, price };
}
