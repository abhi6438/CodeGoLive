const cds = require('@sap/cds');
module.exports = cds.service.impl(async function () {
  const { Books } = this.entities;

  this.after('UPDATE', 'Books', async (_, req) => {
    const db = await cds.connect.to('db');
    const [book] = await db.run(SELECT.one.from(Books).where({ ID: req.data.ID }));
    if (book && book.stock < 5) {
      await this.emit('StockAlert', { bookId: book.ID, currentStock: book.stock });
    }
  });

  this.on('StockAlert', (msg) => {
    console.log(`[Alert] Low stock: book=${msg.data.bookId} stock=${msg.data.currentStock}`);
  });
});