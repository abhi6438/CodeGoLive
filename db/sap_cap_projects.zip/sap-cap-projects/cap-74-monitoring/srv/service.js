const cds = require('@sap/cds');
module.exports = cds.service.impl(async function () {
  this.on('health', () => ({
    status:    'UP',
    timestamp: new Date().toISOString(),
    version:   process.env.APP_VERSION || '1.0.0'
  }));
});