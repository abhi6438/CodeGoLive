const cds = require('@sap/cds');
module.exports = cds.service.impl(async function () {
  const { Books } = this.entities;

  this.on('bookStats', async () => {
    const db = await cds.connect.to('db');
    const [stats] = await db.run(
      SELECT.one.from(Books).columns(
        'count(*) as totalBooks',
        'avg(price) as avgPrice',
        'min(price) as minPrice',
        'max(price) as maxPrice'
      )
    );
    return stats;
  });
});