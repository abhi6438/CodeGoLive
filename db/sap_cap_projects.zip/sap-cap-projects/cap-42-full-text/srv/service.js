const cds = require('@sap/cds');
module.exports = cds.service.impl(async function () {
  const { Books } = this.entities;

  this.on('READ', 'Books', async (req) => {
    const db = await cds.connect.to('db');
    if (req.query.SELECT?.search) {
      const term = req.query.SELECT.search[0]?.val || '';
      return db.run(
        SELECT.from(Books).where(`title like`, `%${term}%`)
      );
    }
    return db.run(req.query);
  });
});