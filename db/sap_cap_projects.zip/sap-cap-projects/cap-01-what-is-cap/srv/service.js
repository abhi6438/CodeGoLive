const cds = require('@sap/cds');

module.exports = cds.service.impl(async function () {
  // Generic handlers provided by @sap/cds automatically.
  // Add custom on() / before() / after() hooks here when needed.
});
