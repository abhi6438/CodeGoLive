const cds = require('@sap/cds');
module.exports = cds.service.impl(async function () {
  // In production: connect to S4 via destination
  // const s4 = await cds.connect.to('S4_BUSINESS_PARTNER');
  const db = await cds.connect.to('db');
  const { Books } = this.entities;

  this.on('READ', 'Books', (req) => db.run(req.query));

  this.on('syncFromS4', async (req) => {
    // Mock: in real scenario, call S4 BP API and upsert
    return { synced: 0, message: 'Mock S4 sync — connect to real destination in production' };
  });
});