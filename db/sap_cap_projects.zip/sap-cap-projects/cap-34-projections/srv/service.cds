using cap.demo as db from '../db/schema';

service CatalogService {
  @cds.redirection.target
  entity Books   as projection on db.Books;
  entity Authors as projection on db.Authors;

  entity PublicBooks as select from db.Books
    excluding { stock }
    { *, price * 1.2 as priceWithTax : Decimal(10,2) };
}
