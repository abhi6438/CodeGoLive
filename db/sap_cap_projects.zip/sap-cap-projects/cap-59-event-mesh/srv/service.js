const cds = require('@sap/cds');
module.exports = cds.service.impl(async function () {
  const { Books } = this.entities;

  this.on('placeOrder', async (req) => {
    const { bookId, qty, buyer } = req.data;
    const db = await cds.connect.to('db');
    const [book] = await db.run(SELECT.one.from(Books).where({ ID: bookId }));
    if (!book) return req.reject(404, `Book ${bookId} not found`);
    if (book.stock < qty) return req.reject(400, 'Insufficient stock');
    await db.run(UPDATE(Books).set({ stock: { '-=': qty } }).where({ ID: bookId }));
    await this.emit('OrderPlaced', { bookId, qty, buyer });
    return { bookId, qty, buyer, status: 'confirmed' };
  });

  this.on('OrderPlaced', (msg) => {
    console.log(`[EventMesh] OrderPlaced → ${JSON.stringify(msg.data)}`);
  });
});