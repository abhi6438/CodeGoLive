const cds = require('@sap/cds');
module.exports = cds.service.impl(async function () {
  this.on('READ', 'Books', async (req) => {
    // In production, swap 'db' with a destination-bound external service
    const db = await cds.connect.to('db');
    return db.run(req.query);
  });
});