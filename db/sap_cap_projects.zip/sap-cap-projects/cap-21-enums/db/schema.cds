namespace cap.demo;

using { managed, cuid } from '@sap/cds/common';

// ── Core entities used across all topics ─────────────────────────────────────

entity Books {
  key ID     : Integer;
      title  : String(100) @mandatory;
      price  : Decimal(10,2) @assert.range: [0, 9999];
      stock  : Integer default 0;
      author : Association to Authors;
}

entity Authors {
  key ID   : Integer;
      name : String(100);
      books : Association to many Books on books.author = $self;
}
  type Priority : String enum {
    LOW    = 'L';
    MEDIUM = 'M';
    HIGH   = 'H';
  }
  entity Tickets {
    key ID       : Integer;
        subject  : String(200);
        priority : Priority default 'M';
  }
