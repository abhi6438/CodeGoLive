const cds = require('@sap/cds');
module.exports = cds.service.impl(async function () {
  this.on('callBapi', async (req) => {
    const { bapiName, params } = req.data;
    // In production: const rfc = require('node-rfc'); client.call(bapiName, JSON.parse(params))
    return `[Mock] BAPI ${bapiName} called with params: ${params}`;
  });
});