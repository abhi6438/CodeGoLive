/**
 * Test: BAPI & RFC
 * Topic: cap-62-bapi-rfc
 *
 * Calls callBapi action and confirms mock response is returned.
 *
 * Run: npm test
 */
const cds = require('@sap/cds');
const { GET, POST, PATCH, DELETE, expect } = cds.test('.').in(__dirname + '/..');

describe('BAPI & RFC', () => {

  it('GET /odata/v4/catalog/Books returns a list', async () => {
    const { data } = await GET '/odata/v4/catalog/Books';
    expect(data.value).to.be.an('array');
  });

  it('POST /odata/v4/catalog/Books creates a new book', async () => {
    const { status, data } = await POST('/odata/v4/catalog/Books', {
      ID: 999,
      title: 'Test Book for BAPI & RFC',
      price: 19.99,
      stock: 5
    });
    expect(status).to.equal(201);
    expect(data.ID).to.equal(999);
  });

  it('PATCH /odata/v4/catalog/Books(999) updates the book', async () => {
    const { status } = await PATCH('/odata/v4/catalog/Books(999)', { price: 24.99 });
    expect(status).to.equal(200);
  });

  it('DELETE /odata/v4/catalog/Books(999) removes the book', async () => {
    const { status } = await DELETE '/odata/v4/catalog/Books(999)';
    expect(status).to.equal(204);
  });

});
