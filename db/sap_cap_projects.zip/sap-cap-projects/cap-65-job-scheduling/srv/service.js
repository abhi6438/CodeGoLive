const cds = require('@sap/cds');
module.exports = cds.service.impl(async function () {
  this.on('runJob', async (req) => {
    const { jobName } = req.data;
    console.log(`[Job] Executing: ${jobName} at ${new Date().toISOString()}`);
    // Simulate job work
    return `Job '${jobName}' completed at ${new Date().toISOString()}`;
  });
});