using cap.demo as db from '../db/schema';

service CatalogService {
  entity Books   as projection on db.Books;
  entity Authors as projection on db.Authors;

  action   restock(bookId: Integer, qty: Integer) returns String;
  function topBooks(limit: Integer)               returns array of Books;
}
