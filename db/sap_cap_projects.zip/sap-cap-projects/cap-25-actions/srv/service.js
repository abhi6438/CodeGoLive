const cds = require('@sap/cds');
module.exports = cds.service.impl(async function () {
  const { Books } = this.entities;

  this.on('restock', async (req) => {
    const { bookId, qty } = req.data;
    const db = await cds.connect.to('db');
    await db.run(UPDATE(Books).set({ stock: { '+=': qty || 10 }}).where({ ID: bookId }));
    return `Book ${bookId} restocked by ${qty || 10} units`;
  });

  this.on('topBooks', async (req) => {
    const db = await cds.connect.to('db');
    return db.run(SELECT.from(Books).orderBy('price desc').limit(req.data.limit || 3));
  });
});