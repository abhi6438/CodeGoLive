const cds = require('@sap/cds');
module.exports = cds.service.impl(async function () {
  this.before('CREATE', 'Books', (req) => {
    const errors = [];
    if (!req.data.title)  errors.push({ message: 'Title is required',         target: 'title' });
    if (req.data.price < 0) errors.push({ message: 'Price must be >= 0',      target: 'price' });
    if (req.data.stock < 0) errors.push({ message: 'Stock must be >= 0',      target: 'stock' });
    if (errors.length) {
      errors.forEach(e => req.error(400, e.message, e.target));
    }
  });
});