const cds = require('@sap/cds');
module.exports = cds.service.impl(async function () {
  this.on('purchase', async (req) => {
    const { bookId, qty } = req.data;
    await this.emit('BookPurchased', { bookId, qty });
    return { bookId, qty, status: 'purchased' };
  });

  this.on('BookPurchased', async (msg) => {
    console.log(`[Event] BookPurchased: book=${msg.data.bookId} qty=${msg.data.qty}`);
  });
});