using cap.demo as db from '../db/schema';

service CatalogService {
  @restrict: [
    { grant: 'READ',  to: 'Viewer' },
    { grant: '*',     to: 'Editor' }
  ]
  entity Books   as projection on db.Books;
  entity Authors as projection on db.Authors;
}
