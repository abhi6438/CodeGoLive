const cds = require('@sap/cds');
module.exports = cds.service.impl(async function () {
  this.on('READ', 'Books', async (req) => {
    // Demonstrates passing user identity downstream
    const userId = req.user?.id || 'anonymous';
    console.log(`[PrincipalProp] Forwarding user: ${userId}`);
    const db = await cds.connect.to('db');
    return db.run(req.query);
  });
});