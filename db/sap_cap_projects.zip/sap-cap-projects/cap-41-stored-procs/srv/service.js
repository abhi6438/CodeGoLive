const cds = require('@sap/cds');
module.exports = cds.service.impl(async function () {
  const { Books } = this.entities;

  this.on('bulkDiscount', async (req) => {
    const { pct = 10 } = req.data;
    const db = await cds.connect.to('db');
    // In dev: use CQL UPDATE; in HANA: call stored procedure
    const count = await db.run(
      UPDATE(Books).set({ price: { '*=': (100 - pct) / 100 } })
    );
    return `Applied ${pct}% discount to ${count} books`;
  });
});