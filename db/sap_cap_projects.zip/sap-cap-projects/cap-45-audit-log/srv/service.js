const cds = require('@sap/cds');
module.exports = cds.service.impl(async function () {
  const { Books } = this.entities;

  this.after('CREATE', 'Books', (result, req) => {
    console.log(`[Audit] Book created: ID=${result.ID} by user=${req.user?.id || 'anonymous'}`);
  });

  this.after('DELETE', 'Books', (_, req) => {
    console.log(`[Audit] Book deleted: key=${JSON.stringify(req.params)} by user=${req.user?.id || 'anonymous'}`);
  });
});