const cds = require('@sap/cds');
module.exports = cds.service.impl(async function () {
  this.before(['CREATE','UPDATE'], 'Books', (req) => {
    if (req.data.price !== undefined && req.data.price < 0)
      return req.reject(400, 'Price cannot be negative');
  });

  this.after('READ', 'Books', (books, req) => {
    books.forEach(b => {
      b.inStock = (b.stock ?? 0) > 0;
    });
  });
});