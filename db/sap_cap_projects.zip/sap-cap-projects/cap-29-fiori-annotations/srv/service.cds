using cap.demo as db from '../db/schema';

service CatalogService {
  entity Books   as projection on db.Books;
  entity Authors as projection on db.Authors;

  @UI.HeaderInfo: { TypeName: 'Book', TypeNamePlural: 'Books', Title: { Value: title } }
  annotate Books with @(
    UI.LineItem: [
      { Value: title,  Label: 'Title' },
      { Value: price,  Label: 'Price' },
      { Value: stock,  Label: 'Stock' }
    ],
    UI.SelectionFields: [ price ],
    UI.FieldGroup #main: {
      Data: [
        { Value: title },
        { Value: price },
        { Value: stock }
      ]
    }
  );
}
