const cds = require('@sap/cds');
module.exports = cds.service.impl(async function () {
  // Delegates to the same db in dev/test; swap to external in production
  const db = await cds.connect.to('db');
  const { Books } = this.entities;

  this.on('READ', 'Books', async (req) => {
    return db.run(req.query);
  });
});