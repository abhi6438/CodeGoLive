const cds = require('@sap/cds');
module.exports = cds.service.impl(async function () {
  this.before('CREATE', 'Books', (req) => {
    const { title, price, stock } = req.data;
    if (!title || title.trim().length < 3)
      req.error(400, 'Title must be at least 3 characters', 'title');
    if (price == null || price < 0 || price > 9999)
      req.error(400, 'Price must be between 0 and 9999', 'price');
    if (stock == null || !Number.isInteger(stock) || stock < 0)
      req.error(400, 'Stock must be a non-negative integer', 'stock');
  });
});