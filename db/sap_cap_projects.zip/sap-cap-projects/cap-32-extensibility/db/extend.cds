using cap.demo as db from './schema';

extend entity db.Books with {
  isbn  : String(20);
  genre : String(50) default 'General';
}
