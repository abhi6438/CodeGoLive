const cds = require('@sap/cds');
module.exports = cds.service.impl(async function () {
  this.on('readinessCheck', async () => {
    let dbOk = false;
    try {
      const db = await cds.connect.to('db');
      await db.run(SELECT.one.from('Books'));
      dbOk = true;
    } catch { dbOk = false; }

    const authOk = !!cds.env.requires?.auth;
    const loggingOk = true; // cds.log is always available

    return { auth: authOk, db: dbOk, logging: loggingOk, overall: dbOk && loggingOk };
  });
});