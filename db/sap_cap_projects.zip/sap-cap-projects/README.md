# SAP CAP Learning Projects

Runnable Node.js projects for every topic in the **SAP CAP (Cloud Application Programming Model)** course on CodeGoLive.

Each folder is a self-contained CAP application you can clone, install, run, and test locally — no BTP account needed for the basics.

---

## Quick Start (any project)

```bash
# 1. Enter a topic folder
cd cap-01-what-is-cap

# 2. Install dependencies
npm install

# 3. Start the CAP server
npm start
# → http://localhost:4004

# 4. Run tests
npm test
```

That's it. Every project uses an **in-memory SQLite** database — nothing to configure.

---

## Module Overview

| Module | Topics | Focus |
|--------|--------|-------|
| M1 — CAP Foundations | cap-01 → cap-10 | Project setup, entities, OData, generic handlers |
| M2 — CDS Data Modeling | cap-11 → cap-22 | Associations, aspects, views, annotations, i18n, drafts, enums |
| M3 — Service Development | cap-23 → cap-32 | Custom handlers, actions, events, error handling, extensibility |
| M4 — Persistence & HANA | cap-33 → cap-46 | Remote services, HANA, HDI, migrations, full-text search, audit log |
| M5 — Auth & Authorization | cap-47 → cap-56 | XSUAA, xs-security.json, @requires, JWT, mock auth, IAS |
| M6 — BTP Services | cap-57 → cap-68 | Destination, Event Mesh, S/4HANA, Workflow, Job Scheduling |
| M7 — Deployment & Production | cap-69 → cap-80 | MTA, CF deploy, CI/CD, multitenancy, SaaS Registry, performance |

---

## What Each Project Contains

```
cap-XX-topic-name/
├── package.json          # @sap/cds ^8, jest ^29, sqlite3 ^5
├── .cdsrc.json           # SQLite in-memory config
├── .env.example          # Environment variable placeholders
├── .gitignore
├── db/
│   ├── schema.cds        # CDS entity definitions
│   └── data/             # CSV seed data (Books + Authors)
├── srv/
│   ├── service.cds       # OData service definition
│   └── service.js        # Custom handlers (topic-specific)
├── test/
│   └── service.test.js   # Jest tests using cds.test()
└── README.md             # Topic-specific quick start + key concepts
```

---

## Running Tests

Each project ships with **4 Jest tests** that exercise the OData API end-to-end:

```
✓ GET /odata/v4/catalog/Books returns a list
✓ POST /odata/v4/catalog/Books creates a book
✓ PATCH /odata/v4/catalog/Books(1) updates a book
✓ DELETE /odata/v4/catalog/Books(3) deletes a book
```

Tests use `cds.test()` — no network or external services needed.

---

## Prerequisites

| Tool | Version |
|------|---------|
| Node.js | 18 or 20 LTS |
| npm | 9+ |
| @sap/cds | installed via npm (in each project) |

> **No SAP BTP account needed** for local development and tests.  
> Module 7 projects (MTA, CF deploy) include deployment templates but local testing still works without BTP.

---

## Special Files (certain topics)

- `cap-15` — multi-file CDS import (`db/common-types.cds`)
- `cap-17` — localization files (`_i18n/i18n.properties`, `i18n_de.properties`)
- `cap-32` — entity extension (`db/extend.cds`)
- `cap-69` — MTA deployment template (`mta.yaml`, `xs-security.json`)
- `cap-73` — GitHub Actions CI pipeline (`.github/workflows/ci.yml`)

---

## License

Educational use. Code examples are illustrative — for production use, add proper error handling, authentication, and testing appropriate to your scenario.

SAP, BTP, CAP, SAPUI5 are trademarks of SAP SE. These projects are not affiliated with or endorsed by SAP SE.
