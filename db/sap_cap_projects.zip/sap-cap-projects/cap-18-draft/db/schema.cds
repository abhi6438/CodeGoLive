namespace cap.demo;

using { managed, cuid } from '@sap/cds/common';

// ── Core entities used across all topics ─────────────────────────────────────

entity Books {
  key ID     : Integer;
      title  : String(100) @mandatory;
      price  : Decimal(10,2) @assert.range: [0, 9999];
      stock  : Integer default 0;
      author : Association to Authors;
}

entity Authors {
  key ID   : Integer;
      name : String(100);
      books : Association to many Books on books.author = $self;
}
  using { managed } from '@sap/cds/common';
  @odata.draft.enabled
  entity Incidents : managed {
    key ID      : UUID;
        title   : String(100) @mandatory;
        status  : String(20) default 'open';
  }
