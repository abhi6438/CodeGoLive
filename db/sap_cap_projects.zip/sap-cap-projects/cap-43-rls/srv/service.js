const cds = require('@sap/cds');
module.exports = cds.service.impl(async function () {
  const { Books } = this.entities;

  this.before('READ', 'Books', (req) => {
    // In production: filter by req.user.tenant or req.user.id
    if (req.user && !req.user.is('admin')) {
      req.query.SELECT.where = [
        ...(req.query.SELECT.where || []),
        'and', { ref: ['price'] }, '<', { val: 100 }
      ];
    }
  });
});