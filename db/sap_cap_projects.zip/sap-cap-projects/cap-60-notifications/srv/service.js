const cds = require('@sap/cds');
module.exports = cds.service.impl(async function () {
  const { Books } = this.entities;

  this.after('UPDATE', 'Books', async (_, req) => {
    const db = await cds.connect.to('db');
    const [book] = await db.run(SELECT.one.from(Books).where({ ID: req.data.ID }));
    if (book?.stock < 3) {
      // In production: POST to Alert Notification Service REST API
      console.log(`[Alert] CRITICAL: Book "${book.title}" stock=${book.stock}`);
    }
  });
});