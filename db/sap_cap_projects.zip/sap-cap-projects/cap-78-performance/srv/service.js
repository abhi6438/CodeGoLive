const cds = require('@sap/cds');
module.exports = cds.service.impl(async function () {
  const { Books } = this.entities;

  // Eager-load association to avoid N+1
  this.on('READ', 'Books', async (req) => {
    const db = await cds.connect.to('db');
    if (!req.query.SELECT?.columns?.some(c => c.expand)) {
      // Force include author in all reads (avoids N+1 in consumers)
      req.query.SELECT.columns = [
        { ref: ['*'] },
        { ref: ['author'], expand: [{ ref: ['*'] }] }
      ];
    }
    return db.run(req.query);
  });
});