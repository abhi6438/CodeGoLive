const cds = require('@sap/cds');
const LOG = cds.log('bookshop');

module.exports = cds.service.impl(async function () {
  const { Books } = this.entities;

  this.before('READ', 'Books', (req) => {
    LOG.info('Books READ requested', { user: req.user?.id, query: req.query?.SELECT?.where });
  });

  this.on('READ', 'Books', async (req) => {
    const db = await cds.connect.to('db');
    const result = await db.run(req.query);
    LOG.debug(`Returned ${result.length} books`);
    return result;
  });
});