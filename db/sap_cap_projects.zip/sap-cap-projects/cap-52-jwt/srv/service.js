const cds = require('@sap/cds');
module.exports = cds.service.impl(async function () {
  this.on('whoAmI', (req) => {
    return {
      id:     req.user?.id     || 'anonymous',
      roles:  req.user?.roles  || [],
      tenant: req.user?.tenant || 'default'
    };
  });
});