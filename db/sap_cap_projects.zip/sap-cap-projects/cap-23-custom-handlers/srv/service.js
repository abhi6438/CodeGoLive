const cds = require('@sap/cds');
module.exports = cds.service.impl(async function () {
  this.before('CREATE', 'Books', (req) => {
    if (!req.data.title) return req.reject(400, 'Title is required');
    req.data.title = req.data.title.trim();
  });

  this.after('READ', 'Books', (books) => {
    for (const b of books) b._computed = `${b.title} — $${b.price}`;
  });
});