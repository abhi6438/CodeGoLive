const cds = require('@sap/cds');
module.exports = cds.service.impl(async function () {
  this.on('startApproval', async (req) => {
    const { bookId, reason } = req.data;
    // In production: POST to /workflow/rest/v1/workflow-instances
    const instanceId = `WF-${Date.now()}`;
    console.log(`[Workflow] Started instance ${instanceId} for book ${bookId}: ${reason}`);
    return instanceId;
  });
});