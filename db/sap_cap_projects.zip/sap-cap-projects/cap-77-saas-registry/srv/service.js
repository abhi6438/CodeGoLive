const cds = require('@sap/cds');
module.exports = cds.service.impl(async function () {
  this.on('onboard', async (req) => {
    const { tenantId, subdomain } = req.data;
    console.log(`[SaaS] Onboarding tenant: ${tenantId} at ${subdomain}`);
    return `https://${subdomain}.app.example.com`;
  });
});