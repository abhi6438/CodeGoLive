# 15_ui5_ai_chat

FastAPI backend for SAP UI5 chat widget. POST /api/chat endpoint.

## Setup

```bash
pip install -r requirements.txt
cp .env.example .env
# Fill in your values in .env
```

## Run

```bash
python main.py
```

## Files

| File | Purpose |
|------|---------|
| `config.py` | Loads env vars, builds HEADERS and URL |
| `main.py` | Application logic |
| `.env.example` | Environment variable template |
| `requirements.txt` | Python dependencies |
