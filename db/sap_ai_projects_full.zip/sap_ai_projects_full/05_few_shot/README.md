# 05_few_shot

Classify SAP error messages into AUTH/DATA/NETWORK/CONFIG using few-shot prompting.

## Setup

```bash
pip install -r requirements.txt
cp .env.example .env
# Fill in your values in .env
```

## Run

```bash
python main.py
```

## Files

| File | Purpose |
|------|---------|
| `config.py` | Loads env vars, builds HEADERS and URL |
| `main.py` | Application logic |
| `.env.example` | Environment variable template |
| `requirements.txt` | Python dependencies |
