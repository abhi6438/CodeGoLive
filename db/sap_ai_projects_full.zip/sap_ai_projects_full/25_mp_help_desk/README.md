# 25_mp_help_desk

Complete CLI help desk chatbot with ticket management.

## Setup

```bash
pip install -r requirements.txt
cp .env.example .env
# Fill in your values in .env
```

## Run

```bash
python main.py
```

## Files

| File | Purpose |
|------|---------|
| `config.py` | Loads env vars, builds HEADERS and URL |
| `main.py` | Application logic |
| `.env.example` | Environment variable template |
| `requirements.txt` | Python dependencies |
