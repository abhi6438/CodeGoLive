# 43_js_genai_hub

SAP GenAI Hub JavaScript example.

## Run

```bash
npm install
node main.js
```
