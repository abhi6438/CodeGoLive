# Episode 8 — Full-Stack CRUD: UI5 + CAP + SQLite

## What you'll build

Add Create, Update, and Delete operations to your connected UI5+CAP app. The Episode 3 CRUD patterns you learned against a local JSON model now talk to the real CAP OData API and persist to SQLite.

---

## Architecture

```
UI5 ODataModel V4
  │
  ├── READ   → GET  /api/Products        (list binding auto-fetches)
  ├── CREATE → POST /api/Products        (oBinding.create({...}))
  ├── UPDATE → PATCH /api/Products(id)   (oContext.setProperty(...) + submitBatch)
  └── DELETE → DELETE /api/Products(id)  (oContext.delete())
          │
     CAP handles routing, validation, and SQL
          │
     SQLite db/demo.db
```

---

## Step 1 — Enable CRUD in the CAP service

By default CAP auto-generates all CRUD operations. But add explicit handlers to customise behaviour:

```js
// srv/product-service.js

const cds = require('@sap/cds');

module.exports = class ProductService extends cds.ApplicationService {

  async init() {

    // Validate before CREATE
    this.before('CREATE', 'Products', (req) => {
      const { name, price } = req.data;
      if (!name || name.trim() === '') {
        req.error(400, 'Product name is required');
      }
      if (price == null || price <= 0) {
        req.error(400, 'Price must be greater than zero');
      }
    });

    // Validate before UPDATE
    this.before('UPDATE', 'Products', (req) => {
      if (req.data.price !== undefined && req.data.price <= 0) {
        req.error(400, 'Price must be greater than zero');
      }
    });

    await super.init();
  }

};
```

`req.error(400, message)` sends a proper OData error response. UI5's ODataModel surfaces this as a rejection in the Promise chain.

---

## Step 2 — UI5 CREATE via ODataModel V4

```js
// In Main.controller.js — onCreatePress handler

onCreatePress: function () {
  // Get the list binding (the "/Products" binding on the List control)
  var oList = this.byId("productList");
  var oBinding = oList.getBinding("items");

  // Create a new entry at the beginning of the list
  // This creates a transient (unsaved) context immediately visible in the UI
  var oContext = oBinding.create({
    name:     "",
    price:    0,
    category_ID: 1
  });

  // Navigate to the detail/edit view for this new (unsaved) context
  this._navToDetail(oContext);
},
```

**Key concept:** `oBinding.create({...})` creates a **transient context**. It appears in the list immediately (optimistic UI) but is not saved until you call `oContext.created()` resolves. If the user cancels, call `oContext.delete()` to discard it.

---

## Step 3 — UI5 UPDATE via ODataModel V4

In the detail/edit view controller:

```js
onSavePress: function () {
  var oContext = this._oContext; // stored when navigating to this view

  // setProperty sends a PATCH for this specific field
  // For multiple fields, batch them:
  var oModel = this.getView().getModel();
  var sPath  = oContext.getPath(); // e.g. /Products(3)

  oModel.setProperty(sPath + "/name",  this.byId("inputName").getValue());
  oModel.setProperty(sPath + "/price", parseFloat(this.byId("inputPrice").getValue()));

  // submitBatch sends all pending PATCH requests in one HTTP call
  oModel.submitBatch("myUpdateGroup")
    .then(function () {
      MessageToast.show("Saved");
      this.onNavBack();
    }.bind(this))
    .catch(function (oError) {
      MessageBox.error("Save failed: " + oError.message);
    });
},
```

**Important:** In OData V4, `setProperty` marks the context as dirty but does NOT send an HTTP request immediately. Only `submitBatch` (or auto-submit depending on your binding group config) sends the PATCH.

---

## Step 4 — UI5 DELETE via ODataModel V4

```js
onDeletePress: function () {
  var oContext = this._oSelectedContext;

  MessageBox.confirm("Delete this product?", {
    onClose: function (sAction) {
      if (sAction !== "OK") { return; }

      oContext.delete()
        .then(function () {
          MessageToast.show("Deleted");
          // List automatically refreshes — the item disappears
        })
        .catch(function (oError) {
          MessageBox.error("Delete failed: " + oError.message);
        });
    }
  });
},
```

`oContext.delete()` sends a `DELETE /api/Products(id)` request. On success the context is removed from the binding and the list updates automatically. No manual refresh needed.

---

## Step 5 — Update manifest.json for auto-expand and batch

```json
"models": {
  "": {
    "dataSource": "mainService",
    "settings": {
      "synchronizationMode": "None",
      "operationMode": "Server",
      "autoExpandSelect": true,
      "groupId": "$auto",
      "updateGroupId": "myUpdateGroup"
    }
  }
}
```

- `"groupId": "$auto"` — READ requests are sent immediately (no manual batch needed for reads).
- `"updateGroupId": "myUpdateGroup"` — all PATCH/POST requests are batched under this group. Only sent when you call `submitBatch("myUpdateGroup")`.

---

## Comparing local JSON CRUD vs OData V4 CRUD

| Operation | JSON Model | OData V4 |
|---|---|---|
| Create | `aProducts.push({...}); oModel.setProperty(...)` | `oBinding.create({...})` → `oModel.submitBatch(...)` |
| Read | Immediate from memory | HTTP GET, async |
| Update | `aProducts[i] = {...}; oModel.setProperty(...)` | `oContext.setProperty(...)` → `oModel.submitBatch(...)` |
| Delete | `aProducts.splice(i,1); oModel.setProperty(...)` | `oContext.delete()` → Promise |
| Error handling | Not needed (local) | `.catch(oError => ...)` always |

---

## Full round-trip trace for a CREATE

```
1. User fills dialog, clicks Save
2. oBinding.create({ name: "New Product", price: 50, category_ID: 1 })
   → item appears in list immediately (transient, unsaved)
3. submitBatch("myUpdateGroup")
   → POST /api/Products  { name: "New Product", price: 50, category_ID: 1 }
4. CAP receives POST
   → runs before('CREATE') handler (validates)
   → CAP inserts row: INSERT INTO com_demo_Products ...
   → CAP returns 201 Created with the full new record (including server-assigned ID)
5. ODataModel receives 201
   → transient context becomes a permanent context with the real ID
   → list binding refreshes the new item's binding
6. MessageToast.show("Created")
```

---

## Common mistakes

**Mistake:** `oBinding.create(...)` throws "Binding must have a create method".
**Fix:** Only list bindings support `create`. Ensure you are calling `getBinding("items")` on the List control, not a property binding on a Text control.

**Mistake:** PATCH is never sent — `submitBatch` resolves immediately with no HTTP request.
**Fix:** `setProperty` must target a property that exists in the OData model's metadata. Check the property name matches exactly (case-sensitive).

**Mistake:** DELETE returns 404.
**Fix:** Make sure the context path includes the key: `/Products(3)`. If `oContext.getPath()` returns `/Products` without a key, you have a binding issue — the context was created without a key predicate.

**Mistake:** CAP returns 400 but the UI shows no error.
**Fix:** Wrap `submitBatch` in `.catch(function(oError) { MessageBox.error(oError.message); })`. By default errors are silent.

---

## ✅ Checkpoint

With both CAP and UI5 servers running:
1. Create a new product via the dialog — it should appear in the list and persist after a browser refresh.
2. Edit a product's name or price — save it and verify the change survives a refresh.
3. Delete a product — it disappears from the list and from `sqlite3 db/demo.db`.