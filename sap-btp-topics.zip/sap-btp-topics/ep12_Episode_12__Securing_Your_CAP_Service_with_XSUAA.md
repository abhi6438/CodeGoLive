# Episode 12 — Securing Your CAP Service with XSUAA

## What you'll build

Add authentication and role-based access control to your CAP service using **XSUAA** (the SAP BTP OAuth2 authorization server). Unauthenticated requests return 401. Requests without the right role return 403.

---

## The security model in three pieces

```
1. xs-security.json  ── defines scopes and role templates
        ↓
2. CDS annotations   ── maps scopes to service operations
        ↓
3. XSUAA service     ── issues JWT tokens containing the user's scopes
        ↓
4. CAP               ── validates the token on every request
```

---

## Step 1 — Create xs-security.json

```json
{
  "xsappname": "product-app",
  "tenant-mode": "dedicated",
  "scopes": [
    {
      "name": "$XSAPPNAME.ProductViewer",
      "description": "Can read products"
    },
    {
      "name": "$XSAPPNAME.ProductAdmin",
      "description": "Can create, update, and delete products"
    }
  ],
  "role-templates": [
    {
      "name": "ProductViewer",
      "description": "Read-only access to products",
      "scope-references": ["$XSAPPNAME.ProductViewer"]
    },
    {
      "name": "ProductAdmin",
      "description": "Full access to products",
      "scope-references": [
        "$XSAPPNAME.ProductViewer",
        "$XSAPPNAME.ProductAdmin"
      ]
    }
  ]
}
```

`$XSAPPNAME` is a placeholder — XSUAA replaces it with the actual app name at deploy time.

---

## Step 2 — Annotate your CDS service

```cds
// srv/product-service.cds

using com.demo from '../db/schema';

@requires: 'authenticated-user'
service ProductService @(path: '/api') {

  @readonly
  @requires: 'ProductViewer'
  entity Products as projection on com.demo.Products;

  @requires: 'ProductAdmin'
  action createProduct(name: String, price: Decimal) returns Products;
}
```

- `@requires: 'authenticated-user'` — the whole service requires a valid JWT token.
- `@readonly` + `@requires: 'ProductViewer'` — GET requests need the Viewer scope.
- `@requires: 'ProductAdmin'` on the action — only admins can call it.

You can also annotate at the operation level:

```cds
entity Products as projection on com.demo.Products {
  @requires: 'ProductViewer'
  READ;
  @requires: 'ProductAdmin'
  CREATE; UPDATE; DELETE;
}
```

---

## Step 3 — Add XSUAA to package.json

```json
{
  "cds": {
    "requires": {
      "db": {
        "kind": "sqlite",
        "credentials": { "database": "db/demo.db" }
      },
      "auth": {
        "kind": "xsuaa"
      }
    }
  }
}
```

In production (`cds run --production`), CAP validates real XSUAA JWTs. In development (`cds watch`), CAP uses mock authentication automatically.

---

## Step 4 — Test mocked auth locally

During development, XSUAA is not available. CAP's mock auth lets you simulate any user and roles:

```bash
# Simulate a ProductViewer user
curl http://localhost:4004/api/Products \
  -H "Authorization: Basic viewer:viewer"

# Simulate a ProductAdmin user (Basic auth: user:password, CAP reads roles from a config)
curl -X POST http://localhost:4004/api/Products \
  -H "Authorization: Basic admin:admin" \
  -H "Content-Type: application/json" \
  -d '{"ID": 10, "name": "Test", "price": 9.99, "category_ID": 1}'
```

To configure mock users, add a `.cdsrc.json`:

```json
{
  "requires": {
    "auth": {
      "kind": "mocked",
      "users": {
        "viewer": { "roles": ["ProductViewer"] },
        "admin":  { "roles": ["ProductViewer", "ProductAdmin"] }
      }
    }
  }
}
```

---

## Viewing a JWT token

When deployed and logged in through the approuter (Episode 14), the token is a Base64-encoded JSON. Decode it:

```bash
# Get the token from the Authorization header, then:
echo "eyJ..." | base64 -d | python3 -m json.tool

# Or use jwt.io in a browser (paste the token)
```

The decoded payload contains `scope` (array of granted scopes) and `user_name`.

---

## Common mistakes

**Mistake:** Adding `@requires` breaks local development — all requests return 401.
**Fix:** Make sure `.cdsrc.json` has the mocked auth config with test users. With `"kind": "mocked"`, CAP accepts Basic auth credentials matching your users config.

**Mistake:** `ProductAdmin` can read but not write — getting 403 on POST.
**Fix:** The `ProductAdmin` role template must include both the `ProductAdmin` AND `ProductViewer` scopes (viewers can read, admins can read+write). Check `xs-security.json` — the admin role-template should reference both scopes.

**Mistake:** Deployed app returns 401 even after login.
**Fix:** The JWT token must be forwarded to CAP. This is the approuter's job (Episode 14). Without the approuter, the browser token is not sent to the CAP backend.

---

## ✅ Checkpoint

With `.cdsrc.json` mocked auth:
1. `curl http://localhost:4004/api/Products` (no auth) → 401
2. `curl -u viewer:viewer http://localhost:4004/api/Products` → 200 with product list
3. `curl -u viewer:viewer -X POST http://localhost:4004/api/Products ...` → 403 (viewer can't write)
4. `curl -u admin:admin -X POST http://localhost:4004/api/Products ...` → 201 Created