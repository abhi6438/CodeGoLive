# Capstone Part 2 — Build the Full UI5 Frontend

## What you'll build

A complete multi-screen UI5 application for your capstone domain: a List view, a Detail/Edit view, and a Create dialog. All screens talk to your Part 1 CAP backend over OData V4.

---

## Your checklist before writing a single line

Answer these before opening a code editor:

1. How many screens do I need? (Usually: List, Detail, maybe a Form)
2. Which entity is the "main" one for each screen?
3. What fields must be visible on the List vs. the Detail?
4. Which fields are editable?
5. Which associations need to be expanded on each screen?

Write these down. A 5-minute design session prevents 50 minutes of refactoring.

---

## Suggested screen structure

For a Task Tracker:

```
List screen (Main.view.xml)
 ├── Shows: task title, priority chip, project name, assignee
 ├── Header: "New Task" button
 ├── Sub-header: SearchField + priority filter
 └── On item press → navigate to Detail

Detail/Edit screen (Detail.view.xml)
 ├── Shows: all task fields
 ├── Edit mode: toggle between read-only display and editable inputs
 ├── Save button → PATCH via OData
 ├── Delete button → DELETE via OData
 └── Back button → navigate to List
```

---

## Routing config template

Copy this routing section into your `manifest.json` and replace `yourapp` with your namespace:

```json
"routing": {
  "config": {
    "routerClass": "sap.m.routing.Router",
    "viewType": "XML",
    "viewPath": "com.yourapp.view",
    "controlId": "app",
    "controlAggregation": "pages",
    "async": true
  },
  "routes": [
    { "name": "list",   "pattern": "",               "target": "list"   },
    { "name": "detail", "pattern": "detail/{taskId}", "target": "detail" }
  ],
  "targets": {
    "list":   { "viewName": "Main",   "viewLevel": 1 },
    "detail": { "viewName": "Detail", "viewLevel": 2 }
  }
}
```

---

## Edit view: create vs edit mode

Reuse one view for both creating a new item and editing an existing one. Use a view model to control the mode:

```js
// Detail.controller.js

onInit: function () {
  // Local view model — controls UI state, not business data
  var oViewModel = new JSONModel({
    editMode:   false,
    isNew:      false,
    pageTitle:  "Task Detail",
    saveEnabled: false
  });
  this.getView().setModel(oViewModel, "view");

  // Attach route handler
  var oRouter = this.getOwnerComponent().getRouter();
  oRouter.getRoute("detail").attachPatternMatched(this._onRouteMatched, this);
},

_onRouteMatched: function (oEvent) {
  var sTaskId = oEvent.getParameter("arguments").taskId;

  if (sTaskId === "new") {
    // CREATE mode
    this.getView().getModel("view").setProperty("/isNew", true);
    this.getView().getModel("view").setProperty("/pageTitle", "New Task");
    this.getView().getModel("view").setProperty("/editMode", true);

    // Create a transient context
    var oBinding = this.getOwnerComponent().getModel()
      .bindList("/Tasks");
    this._oContext = oBinding.create({
      title:      "",
      priority:   "Medium",
      completed:  false
    });
    this.getView().setBindingContext(this._oContext);

  } else {
    // EDIT/VIEW mode — bind to existing task
    this.getView().getModel("view").setProperty("/isNew", false);
    this.getView().getModel("view").setProperty("/pageTitle", "Task Detail");
    this.getView().getModel("view").setProperty("/editMode", false);

    this.getView().bindElement({
      path: "/Tasks(" + sTaskId + ")",
      parameters: { $expand: "project" }
    });
  }
},
```

In the XML view, use `{view>/editMode}` to show/hide controls:

```xml
<!-- Read-only display (visible when not editing) -->
<Text text="{title}" visible="{= !${view>/editMode} }" />

<!-- Editable input (visible when editing) -->
<Input value="{title}" visible="{view>/editMode}" />
```

---

## Value Help on the Project field

```js
onProjectValueHelp: function () {
  if (!this._oProjectDialog) {
    this._oProjectDialog = this.loadFragment({
      name: "com.yourapp.fragments.ProjectDialog"
    });
  }
  Promise.resolve(this._oProjectDialog).then(function (oDialog) {
    this._oProjectDialog = oDialog;
    oDialog.getBinding("items").filter([]);
    oDialog.open();
  }.bind(this));
},

onProjectConfirm: function (oEvent) {
  var oCtx = oEvent.getParameter("selectedItem").getBindingContext();
  this._oContext.setProperty("project_ID", oCtx.getProperty("ID"));
  this._oContext.setProperty("_projectName", oCtx.getProperty("name")); // display only
  oEvent.getSource().getBinding("items").filter([]);
},
```

---

## If you get stuck — which episode to revisit

| Problem | Go back to |
|---|---|
| List does not load data | Episode 7 — OData model setup |
| Navigation between screens fails | Episode 2 — Routing |
| Create/Edit/Delete does not work | Episode 8 — Full-stack CRUD |
| Value help does not load or filter | Episode 9 — Value help with CAP |
| Validation errors not showing | Episode 10 — Validation |
| Search/sort not working | Episode 11 — Filter and sort |

---

## Self-verify before moving to Part 3

| Feature | Works? |
|---|---|
| List loads all items from CAP | ☐ |
| Tapping an item opens the Detail view | ☐ |
| Back button returns to List | ☐ |
| "New" button opens an empty Detail in edit mode | ☐ |
| Filling the form and saving creates a record in the DB | ☐ |
| Editing an existing item and saving updates the DB | ☐ |
| Delete removes the item from the list and the DB | ☐ |
| All bound fields display correct data | ☐ |

---

## Common mistakes

**Mistake:** Create navigates to the detail page but the form is blank and save does nothing.
**Fix:** The transient context must be created on a list binding that is attached to the OData model. Use `this.getOwnerComponent().getModel().bindList("/Tasks")` not a list binding from a view control.

**Mistake:** `bindElement` sets the context but fields show undefined.
**Fix:** The OData key in `bindElement` must match the entity key type. For UUID keys: `/Tasks(550e8400-e29b-41d4-a716-446655440000)`. For integer keys: `/Tasks(1)`. No quotes around UUID or integer.

**Mistake:** Save works for new records but not for edits.
**Fix:** For edits, you need to call `submitBatch("myUpdateGroup")` after `setProperty`. For creates, `oContext.created()` resolves when the server confirms the record.

---

## ✅ Checkpoint

Complete the self-verify checklist above. All seven items must work before moving to Part 3.