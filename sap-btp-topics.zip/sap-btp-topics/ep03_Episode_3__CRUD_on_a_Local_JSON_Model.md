# Episode 3 — CRUD on a Local JSON Model

## What you'll build

A product management screen where you can **Create** new products, **Read** them in a list, **Update** them by editing in place, and **Delete** them — all against a local JSON model. No backend yet. This teaches you the CRUD patterns you'll reuse when you move to OData in Episode 8.

---

## Why local CRUD first?

When you do CRUD against OData (Episode 8), the operation is asynchronous and goes to a server. When you do it against a local JSON model, it is synchronous and immediate. Learning the pattern locally means you can focus on the UI logic without debugging network calls at the same time.

The view code and controller structure you write here transfers almost directly to Episode 8. What changes: `oModel.setProperty()` becomes an OData update binding, and `oModel.getData()` becomes a context create/delete call.

---

## Project structure

```
3-crud-test/
 ├── webapp/
 │   ├── controller/
 │   │   └── Main.controller.js
 │   ├── view/
 │   │   └── Main.view.xml
 │   ├── fragments/
 │   │   └── ProductDialog.fragment.xml   ← reusable create/edit dialog
 │   ├── model/
 │   │   └── data.json
 │   ├── Component.js
 │   ├── index.html
 │   └── manifest.json
 └── package.json
```

---

## File: webapp/model/data.json

Starting data. The controller will add, edit, and delete items from this array.

```json
{
  "products": [
    { "id": "P001", "name": "Laptop Pro 15",     "category": "Electronics", "price": 1299 },
    { "id": "P002", "name": "Wireless Mouse",     "category": "Accessories", "price":   29 },
    { "id": "P003", "name": "USB-C Hub 7-in-1",   "category": "Accessories", "price":   49 }
  ]
}
```

---

## File: webapp/fragments/ProductDialog.fragment.xml

A reusable dialog used for both creating and editing a product. A **Fragment** is a UI5 concept for a piece of view XML that does not have its own controller — it shares the controller of the view that opens it.

```xml
<core:FragmentDefinition
  xmlns="sap.m"
  xmlns:core="sap.ui.core"
  xmlns:l="sap.ui.layout">

  <Dialog
    id="productDialog"
    title="{dialog>/title}"
    resizable="true">

    <content>
      <l:VerticalLayout width="100%" class="sapUiSmallMargin">

        <Label text="Product ID" required="true" />
        <Input
          id="inputId"
          value="{dialog>/id}"
          placeholder="e.g. P004"
          enabled="{dialog>/idEditable}" />

        <Label text="Name" required="true" />
        <Input
          id="inputName"
          value="{dialog>/name}"
          placeholder="Product name" />

        <Label text="Category" required="true" />
        <Select id="selectCategory" selectedKey="{dialog>/category}">
          <core:Item key="Electronics" text="Electronics" />
          <core:Item key="Accessories" text="Accessories" />
          <core:Item key="Software"    text="Software" />
        </Select>

        <Label text="Price (EUR)" required="true" />
        <Input
          id="inputPrice"
          value="{dialog>/price}"
          type="Number"
          placeholder="0" />

      </l:VerticalLayout>
    </content>

    <buttons>
      <Button text="Save"   type="Emphasized" press="onDialogSave" />
      <Button text="Cancel" press="onDialogCancel" />
    </buttons>

  </Dialog>

</core:FragmentDefinition>
```

**Key concept:** The dialog binds to a model named `"dialog"`. The controller creates this model and populates it differently for create vs edit, but the fragment itself doesn't know or care.

---

## File: webapp/view/Main.view.xml

The list with a toolbar containing Create, Edit, and Delete buttons.

```xml
<mvc:View
  controllerName="sap.ui.demo.crud.controller.Main"
  xmlns:mvc="sap.ui.core.mvc"
  xmlns="sap.m"
  xmlns:core="sap.ui.core"
  displayBlock="true">

  <Page title="Product Management">

    <headerContent>
      <Button text="New Product" icon="sap-icon://add"  press="onCreatePress" type="Emphasized" />
    </headerContent>

    <content>
      <List
        id="productList"
        items="{/products}"
        mode="SingleSelectLeft"
        selectionChange="onSelectionChange">

        <headerToolbar>
          <Toolbar>
            <Title text="Products" />
            <ToolbarSpacer />
            <Button id="editBtn"   text="Edit"   icon="sap-icon://edit"   press="onEditPress"   enabled="false" />
            <Button id="deleteBtn" text="Delete" icon="sap-icon://delete" press="onDeletePress" enabled="false" />
          </Toolbar>
        </headerToolbar>

        <StandardListItem
          title="{name}"
          description="{category}"
          info="{price} EUR"
          infoState="Success" />

      </List>
    </content>

  </Page>

</mvc:View>
```

---

## File: webapp/controller/Main.controller.js

All four CRUD operations in one controller.

```js
sap.ui.define([
  "sap/ui/core/mvc/Controller",
  "sap/ui/model/json/JSONModel",
  "sap/m/MessageToast",
  "sap/m/MessageBox"
], function (Controller, JSONModel, MessageToast, MessageBox) {
  "use strict";

  return Controller.extend("sap.ui.demo.crud.controller.Main", {

    // ─── Lifecycle ────────────────────────────────────────────────────────────

    onInit: function () {
      // Keep track of which product is selected (for edit/delete)
      this._selectedIndex = -1;
    },

    // ─── Selection ────────────────────────────────────────────────────────────

    onSelectionChange: function (oEvent) {
      var bSelected = oEvent.getParameter("selected");
      if (bSelected) {
        // Store the model index of the selected item for later use
        var oContext = oEvent.getParameter("listItem").getBindingContext();
        var sPath = oContext.getPath(); // e.g. "/products/1"
        this._selectedIndex = parseInt(sPath.split("/").pop(), 10);
      } else {
        this._selectedIndex = -1;
      }
      // Enable/disable Edit and Delete buttons based on selection
      this.byId("editBtn").setEnabled(bSelected);
      this.byId("deleteBtn").setEnabled(bSelected);
    },

    // ─── CREATE ───────────────────────────────────────────────────────────────

    onCreatePress: function () {
      // Set up a blank dialog model for a new product
      var oDialogModel = new JSONModel({
        title:      "Create Product",
        id:         "",
        name:       "",
        category:   "Electronics",
        price:      0,
        idEditable: true   // ID is editable only when creating
      });

      this._openDialog(oDialogModel, "create");
    },

    // ─── UPDATE (Edit) ────────────────────────────────────────────────────────

    onEditPress: function () {
      if (this._selectedIndex < 0) { return; }

      // Read the selected product from the main model
      var oModel = this.getView().getModel();
      var oProduct = oModel.getProperty("/products/" + this._selectedIndex);

      // Pre-fill the dialog model with existing values
      var oDialogModel = new JSONModel({
        title:      "Edit Product",
        id:         oProduct.id,
        name:       oProduct.name,
        category:   oProduct.category,
        price:      oProduct.price,
        idEditable: false   // ID cannot be changed when editing
      });

      this._openDialog(oDialogModel, "edit");
    },

    // ─── DELETE ───────────────────────────────────────────────────────────────

    onDeletePress: function () {
      if (this._selectedIndex < 0) { return; }

      var oModel = this.getView().getModel();
      var oProduct = oModel.getProperty("/products/" + this._selectedIndex);

      MessageBox.confirm(
        "Delete \"" + oProduct.name + "\"?",
        {
          onClose: function (sAction) {
            if (sAction === "OK") {
              // Remove the item from the array and update the model
              var aProducts = oModel.getProperty("/products");
              aProducts.splice(this._selectedIndex, 1);
              oModel.setProperty("/products", aProducts);
              // Reset selection state
              this._selectedIndex = -1;
              this.byId("editBtn").setEnabled(false);
              this.byId("deleteBtn").setEnabled(false);
              MessageToast.show("Product deleted");
            }
          }.bind(this)
        }
      );
    },

    // ─── Dialog helpers ───────────────────────────────────────────────────────

    _openDialog: function (oDialogModel, sMode) {
      this._dialogMode = sMode;

      // Load the fragment only once, cache it as this._oDialog
      if (!this._oDialog) {
        this._oDialog = this.loadFragment({
          name: "sap.ui.demo.crud.fragments.ProductDialog"
        });
      }

      // this.loadFragment returns a Promise in modern UI5
      Promise.resolve(this._oDialog).then(function (oDialog) {
        this._oDialog = oDialog;
        oDialog.setModel(oDialogModel, "dialog");
        oDialog.open();
      }.bind(this));
    },

    onDialogSave: function () {
      var oDialog    = this._oDialog;
      var oData      = oDialog.getModel("dialog").getData();
      var oModel     = this.getView().getModel();
      var aProducts  = oModel.getProperty("/products");

      // Basic validation
      if (!oData.id || !oData.name) {
        MessageToast.show("ID and Name are required");
        return;
      }

      if (this._dialogMode === "create") {
        // Check for duplicate ID
        var bExists = aProducts.some(function (p) { return p.id === oData.id; });
        if (bExists) {
          MessageToast.show("A product with this ID already exists");
          return;
        }
        aProducts.push({
          id:       oData.id,
          name:     oData.name,
          category: oData.category,
          price:    parseFloat(oData.price) || 0
        });
        MessageToast.show("Product created");
      } else {
        // Edit: update in place
        aProducts[this._selectedIndex] = {
          id:       oData.id,
          name:     oData.name,
          category: oData.category,
          price:    parseFloat(oData.price) || 0
        };
        MessageToast.show("Product updated");
      }

      oModel.setProperty("/products", aProducts);
      oDialog.close();
    },

    onDialogCancel: function () {
      this._oDialog.close();
    }

  });
});
```

---

## READ — it is just binding

You never write code to "read" data from a JSON model. UI5 binding handles it automatically. When you call `oModel.setProperty("/products", aProducts)` after a create, edit, or delete, every bound control (the list, any labels) updates automatically. This is the power of two-way binding.

---

## What changes when you move to OData (Episode 8)

| Local JSON | OData V4 |
|---|---|
| `aProducts.push({...}); oModel.setProperty(...)` | `oBinding.create({...})` |
| `aProducts.splice(i, 1); oModel.setProperty(...)` | `oContext.delete()` |
| `aProducts[i] = {...}; oModel.setProperty(...)` | `oContext.setProperty("name", value)` then `oModel.submitBatch()` |
| Instant, synchronous | Asynchronous, returns a Promise |

---

## Common mistakes

**Mistake:** Dialog opens but the inputs are blank even when editing.
**Fix:** Make sure `oDialog.setModel(oDialogModel, "dialog")` is called every time the dialog opens, not just the first time. The model must be refreshed per-open.

**Mistake:** `this.loadFragment` throws "loadFragment is not a function".
**Fix:** You are on an older UI5 version. Use `sap.ui.xmlfragment(this.getView().getId(), "...fragments.ProductDialog", this)` as the fallback.

**Mistake:** Delete removes the wrong item after the list reorders.
**Fix:** `this._selectedIndex` stores the array index. After a delete, call `this.byId("productList").removeSelections(true)` to clear the list selection state, then reset `_selectedIndex = -1`.

**Mistake:** Edited price saves as a string, not a number.
**Fix:** Always wrap the price value with `parseFloat()` before saving to the array.

---

## ✅ Checkpoint

Run `npm start`. You should be able to:
1. See the list of 3 products.
2. Click **New Product** → fill the form → **Save** → see the new item appear in the list.
3. Select any item → click **Edit** → change the name → **Save** → see the list update.
4. Select any item → click **Delete** → confirm → see it removed from the list.