# Episode 13 — BTP Destinations: Portable Service URLs

## What you'll build

Replace the hardcoded `http://localhost:4004` URL in your app with a **BTP Destination** — a named, managed connection that works in both local development and production without changing any app code.

---

## The problem with hardcoded URLs

In Episode 7 you set up a proxy in `ui5.yaml` pointing to `http://localhost:4004`. This works locally, but when you deploy to BTP:
- The CAP service runs at a different URL (e.g. `https://my-cap-service.cfapps.eu10.hana.ondemand.com`).
- That URL changes between landscapes (dev, test, prod).
- Hardcoding it means updating code for every deployment.

A Destination solves this: the app always calls `/backend/api/Products` and the approuter (Episode 14) resolves `backend` to whatever URL is configured in the BTP Destination service — without any code change.

---

## The destination solution

```
UI5 app calls: /backend/api/Products
        ↓
Approuter reads xs-app.json: route /backend/* → destination "cap-backend"
        ↓
BTP Destination service: "cap-backend" = https://my-cap-service.cfapps.eu10.hana.ondemand.com
        ↓
CAP service receives: GET /api/Products
```

---

## Step 1 — Create a destination in BTP Cockpit

1. In BTP Cockpit, go to **Connectivity → Destinations**.
2. Click **New Destination**.
3. Fill in:

| Field | Value |
|---|---|
| Name | `cap-backend` |
| Type | `HTTP` |
| URL | `https://your-cap-service-url.cfapps.eu10.hana.ondemand.com` |
| Proxy Type | `Internet` |
| Authentication | `NoAuthentication` (or `OAuth2UserTokenExchange` if the service requires auth) |

4. Save.

For local development, you can define the destination in a `default-env.json` file (never commit this to git):

```json
{
  "destinations": [
    {
      "name": "cap-backend",
      "url": "http://localhost:4004",
      "forwardAuthToken": false
    }
  ]
}
```

---

## Step 2 — Update manifest.json to use relative URL

Remove the hardcoded host. The approuter will prepend the correct host.

```json
{
  "sap.app": {
    "dataSources": {
      "mainService": {
        "uri": "/backend/api/",
        "type": "OData",
        "settings": { "odataVersion": "4.0" }
      }
    }
  }
}
```

The path `/backend/api/` works in both local (proxied to `localhost:4004/api/`) and deployed (routed by the approuter through the BTP destination).

---

## Step 3 — Configure xs-app.json in the approuter

The approuter reads `xs-app.json` to know which URL patterns map to which destinations:

```json
{
  "authenticationMethod": "route",
  "routes": [
    {
      "source": "^/backend/(.*)$",
      "target": "/$1",
      "destination": "cap-backend",
      "authenticationType": "xsuaa",
      "csrfProtection": false
    },
    {
      "source": "^/(.*)$",
      "target": "$1",
      "service": "html5-apps-repo-rt",
      "authenticationType": "xsuaa"
    }
  ]
}
```

- `"source": "^/backend/(.*)$"` — any request starting with `/backend/` is matched.
- `"target": "/$1"` — the matched path (after `/backend/`) is forwarded to the destination.
- `"destination": "cap-backend"` — the name of the BTP Destination to use.

---

## Common mistakes

**Mistake:** Local development still fails after setting up `default-env.json`.
**Fix:** `default-env.json` is read by `@sap/approuter` when running locally. Make sure you start the approuter with `node node_modules/@sap/approuter/approuter.js`, not `cds watch`. Or keep the `ui5.yaml` proxy for the UI5 dev server.

**Mistake:** In production, requests return 404 for `/backend/api/Products`.
**Fix:** Check that the destination name in `xs-app.json` (`"cap-backend"`) exactly matches the name in BTP Cockpit. Names are case-sensitive.

**Mistake:** BTP Destination test (the "Check Connection" button in Cockpit) passes but the app still fails.
**Fix:** The "Check Connection" test only checks if the destination URL is reachable. It does not test authentication. If the CAP service requires an XSUAA token, set `"authenticationType": "xsuaa"` on the route.

---

## ✅ Checkpoint

Locally:
1. Start the approuter pointing to `default-env.json`.
2. Open your UI5 app through the approuter port (not the UI5 dev server directly).
3. The product list loads — the network tab shows requests to `/backend/api/Products`, not `localhost:4004`.

In BTP:
- Deploy the destination and approuter, then open the app URL.
- Products load from the deployed CAP service without any URL in the app code.