# Episode 0 — Setup: BTP Trial, BAS, and Your First Project

## What you'll build

A working SAP BTP trial account, an active Business Application Studio (BAS) dev space, and a scaffolded SAPUI5 project you can run in the browser — all before writing a single line of app code.

---

## Why this matters

Every topic in this course runs inside SAP BTP. Getting the environment right once means everything else just works. Skipping steps here causes silent failures later.

---

## Step 1 — Create your BTP Trial account

Go to [https://www.sap.com/products/technology-platform/trial.html](https://www.sap.com/products/technology-platform/trial.html) and click **Start your free trial**.

- Use a personal email (not a corporate one — corporate emails sometimes block verification).
- Choose the region closest to you (US East, Europe, or AP).
- After email verification you land on the **BTP Cockpit**.

> **What is BTP Cockpit?** It is the control panel for all your cloud services — databases, runtimes, destinations, and the dev environment you'll use next.

---

## Step 2 — Open Business Application Studio

In the BTP Cockpit:

1. Click **Services → Service Marketplace**.
2. Search for **SAP Business Application Studio**.
3. Click the tile → **Create** a new subscription (free tier).
4. Once provisioned, click **Go to Application**.

BAS opens in a new browser tab. It looks like VS Code because it is built on the same engine.

---

## Step 3 — Create a Dev Space

A Dev Space is a pre-configured container with the tools you need already installed.

1. Click **Create Dev Space**.
2. Name it (e.g. `UI5CAP`).
3. Choose **SAP Fiori** as the kind.
4. Click **Create Dev Space** and wait ~1 minute for it to start (green dot).

> **Why SAP Fiori kind?** It pre-installs the UI5 CLI, CAP CLI (`cds`), and all Fiori generators. You would have to install these manually with any other kind.

---

## Step 4 — Scaffold your first project

Inside BAS, open a terminal: **Terminal → New Terminal**.

```bash
# Install the Yeoman generator for UI5 (only needed once per dev space)
npm install -g yo generator-easy-ui5

# Scaffold a basic UI5 app
yo easy-ui5 project
```

Answer the prompts:
- Target platform: **Application Router Managed Approuter** (choose Simple for now)
- Namespace: `sap.ui.demo.ep0`
- View name: `Main`

The generator creates this structure:

```
ep0/
 ├── webapp/
 │   ├── controller/
 │   │   └── Main.controller.js
 │   ├── view/
 │   │   └── Main.view.xml
 │   ├── Component.js
 │   ├── index.html
 │   └── manifest.json
 └── package.json
```

---

## Step 5 — Run the preview

```bash
cd ep0
npm install
npm start
```

BAS shows a popup — click **Open in New Tab**. You'll see the default Fiori shell with a blank page. That blank page is your app.

> **Nothing shows yet** — that is expected. The view is empty. You'll add content in Episode 1.

---

## Tools to install before Episode 1

Open the terminal and run these once. They stay installed for the lifetime of your dev space:

```bash
# CAP CLI (needed from Episode 5 onward)
npm install -g @sap/cds-dk

# Verify everything is ready
node --version      # should be 18 or 20
ui5 --version       # should be 3.x
cds --version       # should be 7.x or 8.x
```

---

## How the course is structured

| Episodes | Topic |
|---|---|
| 1–4 | Pure SAPUI5 (no backend) |
| 5–6 | CAP backend with SQLite |
| 7–9 | UI5 talking to CAP over OData |
| 10–11 | Validation, search, sort |
| 12–15 | Auth, destinations, approuter, deploy |
| 16–19 | Capstone mini-project |

---

## Common mistakes

**Mistake:** Dev space shows "STOPPED" when you come back the next day.
**Fix:** Trial dev spaces auto-stop after inactivity. Click the play button (▶) to restart. Your files are preserved.

**Mistake:** `yo easy-ui5` command not found.
**Fix:** Run `npm install -g yo generator-easy-ui5` again — the dev space may have been recreated.

**Mistake:** Preview tab shows a connection error.
**Fix:** Make sure `npm install` completed without errors first. Check the terminal for red text.

---

## ✅ Checkpoint

You should have:
- A BTP trial account you can log into.
- A running BAS dev space (green dot).
- A scaffolded project that opens in the browser with a Fiori shell.
- `node`, `ui5`, and `cds` all returning version numbers in the terminal.