# Episode 9 — Value Help Against Live CAP Data

## What you'll build

Upgrade the Episode 4 static category Value Help dialog to load its values dynamically from the CAP `/api/Categories` OData endpoint. The search now filters server-side using OData `$filter`.

---

## What is different from Episode 4

| Episode 4 | Episode 9 |
|---|---|
| Category list hardcoded in `data.json` | Category list fetched from `/api/Categories` |
| Search filters in-browser (Filter on JSONModel) | Search sends `$filter` to CAP (server-side) |
| Adding a new category means editing JSON | Adding a category goes to the database |

The fragment XML stays nearly the same. What changes is the binding in the fragment (OData path instead of JSON path) and the search handler (server-side filter instead of client-side).

---

## Step 1 — The dialog fragment (updated binding)

```xml
<core:FragmentDefinition
  xmlns="sap.m"
  xmlns:core="sap.ui.core">

  <SelectDialog
    id="categoryDialog"
    title="Select Category"
    search="onDialogSearch"
    confirm="onDialogConfirm"
    cancel="onDialogCancel"
    items="{
      path: '/Categories',
      parameters: {
        $select: 'ID,name',
        $orderby: 'name asc'
      }
    }">

    <StandardListItem
      title="{name}"
      description="{ID}"
      type="Active" />

  </SelectDialog>

</core:FragmentDefinition>
```

The binding path `/Categories` now refers to the OData model (set in manifest.json), not the local JSONModel. The `$select` and `$orderby` parameters are sent as query options in the HTTP request.

---

## Step 2 — The search handler (server-side filtering)

```js
onDialogSearch: function (oEvent) {
  var sValue = oEvent.getParameter("value");
  var oBinding = oEvent.getSource().getBinding("items");

  if (sValue) {
    // Build an OData $filter: name contains the search value
    var oFilter = new Filter({
      path: "name",
      operator: FilterOperator.Contains,
      value1: sValue
    });
    oBinding.filter([oFilter]);
    // This sends: GET /api/Categories?$filter=contains(name,'laptop')
  } else {
    // Empty search — remove the filter, show all
    oBinding.filter([]);
  }
},
```

The `Filter` object with `FilterOperator.Contains` generates the OData `contains()` function in the `$filter` query parameter. CAP handles the SQL `LIKE '%value%'` automatically.

---

## Step 3 — Confirm handler (unchanged from Episode 4)

```js
onDialogConfirm: function (oEvent) {
  var oSelectedItem = oEvent.getParameter("selectedItem");
  if (!oSelectedItem) { return; }

  // Get the category ID from the OData context
  var oContext = oSelectedItem.getBindingContext();
  var sCategoryId   = oContext.getProperty("ID");
  var sCategoryName = oContext.getProperty("name");

  // Write the selected category back to the product form
  var oFormModel = this.getView().getModel("form");
  oFormModel.setProperty("/category_ID",   sCategoryId);
  oFormModel.setProperty("/categoryName",  sCategoryName);  // for display only

  // Clean up filter
  oEvent.getSource().getBinding("items").filter([]);
},
```

---

## Step 4 — Open handler (one small addition)

```js
onCategoryValueHelp: function () {
  if (!this._oCategoryDialog) {
    this._oCategoryDialog = this.loadFragment({
      name: "sap.ui.demo.f4b.fragments.CategoryDialog"
    });
  }

  Promise.resolve(this._oCategoryDialog).then(function (oDialog) {
    this._oCategoryDialog = oDialog;

    // Reset filter before opening so the full list shows
    var oBinding = oDialog.getBinding("items");
    if (oBinding) { oBinding.filter([]); }

    oDialog.open();
  }.bind(this));
},
```

---

## Understanding OData $filter

OData `$filter` is a standardised query language. CAP supports the full OData filter spec:

| Filter | OData syntax | UI5 FilterOperator |
|---|---|---|
| Equals | `name eq 'Laptop'` | `EQ` |
| Contains | `contains(name,'lap')` | `Contains` |
| Starts with | `startswith(name,'L')` | `StartsWith` |
| Greater than | `price gt 100` | `GT` |
| AND | `price gt 100 and category eq 'A'` | Combine with `Filter({and: [...]})` |

UI5 translates `FilterOperator` enum values to the correct OData syntax automatically. You never write the OData filter string by hand.

---

## Common mistakes

**Mistake:** Dialog opens empty — no categories load.
**Fix:** The dialog binding uses the default OData model. Confirm `manifest.json` has the OData model declared as the default (empty name `""`). If you have a named model, prefix the path: `path: 'yourModel>/Categories'`.

**Mistake:** Search does nothing — typing in the search box has no effect.
**Fix:** The `search` event on `SelectDialog` does not fire automatically. Verify the `search` attribute in the fragment XML is set to your handler name: `search="onDialogSearch"`.

**Mistake:** Confirming a category gives `undefined` for the ID.
**Fix:** Use `oContext.getProperty("ID")` (capital ID), not `oContext.getObject().id`. OData property names match the CDS definition exactly.

**Mistake:** CAP returns 400 on the filter request.
**Fix:** `FilterOperator.Contains` generates `contains(name,'value')` which requires OData V4. If your service is V2, use `FilterOperator.Contains` → it generates a different syntax. This course uses V4.

---

## ✅ Checkpoint

1. Open the product form.
2. Click the Category value help icon — the dialog loads category names from CAP.
3. Type "el" in the search box — the list filters to show only "Electronics".
4. Select a category — the Category field in the form updates.
5. Open `http://localhost:4004/api/Categories?$filter=contains(name,'el')` in a browser to verify CAP is filtering correctly server-side.