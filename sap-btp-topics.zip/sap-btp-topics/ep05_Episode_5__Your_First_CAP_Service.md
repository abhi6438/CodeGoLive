# Episode 5 — Your First CAP Service

## What you'll build

A running OData API built with SAP Cloud Application Programming model (CAP). You define a data model in CDS, expose it as a service, and query it with a browser. No database yet — CAP uses an in-memory store automatically.

---

## Why CAP?

CAP lets you define your entire backend — data model, service, security rules — in a high-level domain language (CDS). It generates the OData API, handles pagination, sorting, filtering, and associations automatically. You write almost no boilerplate.

| Hand-rolled Express API | CAP |
|---|---|
| Write router, controllers, SQL queries | Describe your model in CDS |
| Handle OData protocol manually | CAP generates full OData V4 |
| Write auth middleware | Annotate with `@requires` |

---

## Project structure

```
5-cap-1-test/
 ├── db/
 │   └── schema.cds        ← data model definition
 ├── srv/
 │   ├── product-service.cds   ← service definition (which entities to expose)
 │   └── product-service.js    ← optional: custom logic handlers
 ├── package.json
 └── .cdsrc.json           ← CAP configuration
```

---

## Step 1 — Install the CAP CLI

```bash
npm install -g @sap/cds-dk

# Verify
cds --version   # should print 7.x or 8.x
```

---

## Step 2 — Scaffold the project

```bash
cds init 5-cap-1-test
cd 5-cap-1-test
npm install
```

`cds init` creates the folder structure and a minimal `package.json` pre-configured for CAP.

---

## Step 3 — Define the data model

```cds
// db/schema.cds

namespace com.demo;

entity Products {
  key ID       : Integer;
      name     : String(100);
      category : String(50);
      price    : Decimal(10, 2);
}
```

**What this does:**
- `namespace com.demo` — prefixes all entity names. Your entity is fully named `com.demo.Products`.
- `key ID` — marks `ID` as the primary key. OData uses this for single-record URLs like `/Products(1)`.
- CAP infers the database table structure from this definition. You write no SQL.

---

## Step 4 — Define the service

```cds
// srv/product-service.cds

using com.demo from '../db/schema';

service ProductService @(path: '/api') {
  entity Products as projection on com.demo.Products;
}
```

**What this does:**
- `using` — imports the entity from the schema.
- `service ProductService @(path: '/api')` — exposes the service at `/api`. The full OData URL will be `/api/Products`.
- `projection on` — exposes the entity as-is. You can use projection to rename fields or exclude sensitive ones.

---

## Step 5 — Add an optional custom handler

```js
// srv/product-service.js

const cds = require('@sap/cds');

module.exports = class ProductService extends cds.ApplicationService {

  async init() {
    // Called once when the service starts

    // Example: log every READ request
    this.before('READ', 'Products', (req) => {
      console.log('Reading products, filter:', req.query.SELECT.where);
    });

    // Example: auto-set a default category on CREATE
    this.before('CREATE', 'Products', (req) => {
      if (!req.data.category) {
        req.data.category = 'General';
      }
    });

    await super.init();
  }

};
```

This file is optional — if it does not exist, CAP serves the entity with full auto-CRUD and no custom logic.

---

## File: package.json

```json
{
  "name": "5-cap-1-test",
  "version": "1.0.0",
  "dependencies": {
    "@sap/cds": "^8.0.0",
    "express": "^4.18.0"
  },
  "devDependencies": {
    "@sap/cds-dk": "^8.0.0",
    "sqlite3": "^5.1.0"
  },
  "scripts": {
    "start": "cds run",
    "watch": "cds watch"
  },
  "cds": {
    "requires": {
      "db": {
        "kind": "sqlite",
        "credentials": { "database": ":memory:" }
      }
    }
  }
}
```

**`"database": ":memory:"`** — SQLite in-memory store. Data resets every time you restart the server. You add a real file in Episode 6.

---

## Step 6 — Run it

```bash
cds watch
```

`cds watch` starts the server and auto-restarts on file changes. You should see:

```
[cds] - loaded model from 2 file(s): db/schema.cds, srv/product-service.cds
[cds] - connect to db > sqlite { database: ':memory:' }
[cds] - serving ProductService { path: '/api' }
[cds] - server listening on { url: 'http://localhost:4004' }
```

---

## What CAP generated for you

Open `http://localhost:4004` in a browser. You see the CAP service index page with links to:

| URL | What it does |
|---|---|
| `/api` | OData service document (lists all entity sets) |
| `/api/$metadata` | Full OData metadata XML — describes every entity, field, and type |
| `/api/Products` | Returns all products as JSON |
| `/api/Products(1)` | Returns the product with ID=1 |
| `/api/Products?$filter=category eq 'Electronics'` | Filtered query |
| `/api/Products?$orderby=price desc` | Sorted query |
| `/api/Products?$select=name,price` | Projection query |

All of this works with zero hand-written query code.

---

## Common mistakes

**Mistake:** `cds watch` shows "No model found".
**Fix:** Make sure you are running the command from the project root (where `package.json` is), not from inside `db/` or `srv/`.

**Mistake:** `/api/Products` returns an empty array `{ value: [] }`.
**Fix:** That is correct for an in-memory database with no seed data. Add data in Episode 6 using CSV files.

**Mistake:** CDS file shows a red underline in BAS but `cds watch` still works.
**Fix:** Install the CDS Language Support extension in BAS: **Extensions → search "SAP CDS Language Support"**.

**Mistake:** `cds: command not found`.
**Fix:** Run `npm install -g @sap/cds-dk`. If in BAS, confirm your dev space is the "SAP Fiori" kind which pre-installs this.

---

## ✅ Checkpoint

Run `cds watch`. In a browser, open:
- `http://localhost:4004/api/Products` — should return `{"value": []}` (empty but valid OData response).
- `http://localhost:4004/api/$metadata` — should return an XML document describing the Products entity.