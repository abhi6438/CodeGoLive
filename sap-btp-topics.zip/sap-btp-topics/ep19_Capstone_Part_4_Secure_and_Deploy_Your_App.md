# Capstone Part 4 — Secure and Deploy Your App

## What you'll build

Add XSUAA authentication, configure your `mta.yaml` for production deployment, deploy to SAP BTP Cloud Foundry, and verify the live app end-to-end.

---

## Final checklist overview

Before deploying, confirm every item below is ready:

| Item | Status |
|---|---|
| `xs-security.json` defines scopes and role-templates for your domain | ☐ |
| CDS service annotated with `@requires` | ☐ |
| `mta.yaml` covers all four modules (db-deployer, srv, approuter, ui) | ☐ |
| `xs-app.json` routes `/backend/*` to the CAP destination | ☐ |
| UI5 `manifest.json` uses `/backend/api/` (not localhost) | ☐ |
| All CSV seed files have valid UUIDs or integers | ☐ |
| `npm install` runs without errors in every module folder | ☐ |

---

## Step 1 — xs-security.json for your domain

Adapt this template to your entities. Replace `myapp`, `Viewer`, and `Admin` with names that match your domain:

```json
{
  "xsappname": "myapp",
  "tenant-mode": "dedicated",
  "scopes": [
    {
      "name": "$XSAPPNAME.Viewer",
      "description": "Read access"
    },
    {
      "name": "$XSAPPNAME.Editor",
      "description": "Create, update, and delete access"
    }
  ],
  "role-templates": [
    {
      "name": "Viewer",
      "description": "Read-only",
      "scope-references": ["$XSAPPNAME.Viewer"]
    },
    {
      "name": "Editor",
      "description": "Full access",
      "scope-references": [
        "$XSAPPNAME.Viewer",
        "$XSAPPNAME.Editor"
      ]
    }
  ]
}
```

---

## Step 2 — Annotate your CDS service

```cds
// srv/your-service.cds

@requires: 'authenticated-user'
service YourService @(path: '/api') {

  @readonly
  @requires: 'Viewer'
  entity Tasks as projection on com.yourapp.Tasks;

  @requires: 'Editor'
  action createTask(title: String) returns Tasks;
}
```

---

## Step 3 — mta.yaml for your capstone

```yaml
_schema-version: "3.1"
ID: myapp
version: 1.0.0

modules:

  - name: myapp-srv
    type: nodejs
    path: .
    parameters:
      memory: 256M
    build-parameters:
      builder: npm
    requires:
      - name: myapp-db
      - name: myapp-xsuaa
    provides:
      - name: srv-api
        properties:
          srv-url: ${default-url}

  - name: myapp-db-deployer
    type: hdb
    path: gen/db
    requires:
      - name: myapp-db

  - name: myapp-approuter
    type: approuter.nodejs
    path: approuter
    parameters:
      memory: 128M
    requires:
      - name: myapp-xsuaa
      - name: myapp-html5-repo-runtime
      - name: srv-api
        group: destinations
        properties:
          name: cap-backend
          url: ~{srv-url}
          forwardAuthToken: true

  - name: myapp-ui
    type: html5
    path: webapp
    build-parameters:
      build-result: dist
      builder: custom
      commands:
        - npm install
        - npm run build

resources:

  - name: myapp-db
    type: com.sap.xs.hdi-container
    parameters:
      service: hana
      service-plan: hdi-shared

  - name: myapp-xsuaa
    type: org.cloudfoundry.managed-service
    parameters:
      service: xsuaa
      service-plan: application
      config:
        xsappname: myapp
        tenant-mode: dedicated
        path: xs-security.json

  - name: myapp-html5-repo-runtime
    type: org.cloudfoundry.managed-service
    parameters:
      service: html5-apps-repo
      service-plan: app-runtime
```

---

## Step 4 — Build

```bash
# Build all modules into the .mtar archive
mbt build

# Expected output:
# INFO Cloud MTA Build Tool version ...
# INFO Generating "META-INF/mtad.yaml"...
# INFO Building module "myapp-srv"...
# INFO Building module "myapp-ui"...
# INFO Generating MTA archive...
# INFO Done packaging MTA project!
```

If `mbt build` fails, the error message names the failing module. Fix that module's `npm install` or build script first.

---

## Step 5 — Build and deploy

```bash
# Log in (if not already logged in)
cf login -a https://api.cf.eu10.hana.ondemand.com

# Deploy
cf deploy mta_archives/myapp_1.0.0.mtar --strategy rolling

# Watch progress
cf apps
```

The `--strategy rolling` flag deploys the new version alongside the old one and switches traffic only after the new one is healthy. Safer than the default stop-start for production.

---

## Step 6 — Post-deployment: create the destination

After `cf deploy`:
1. Go to **BTP Cockpit → Connectivity → Destinations**.
2. Create a destination named `cap-backend` (or verify it was auto-created by the MTA).
3. Set the URL to the CAP service URL shown in `cf apps` under `myapp-srv`.
4. Authentication: `No Authentication` for now (the approuter handles auth via token exchange).

---

## Step 7 — Assign yourself a role collection

After deployment you will get a 403 even as the logged-in user until you assign yourself a role:

1. Go to **BTP Cockpit → Security → Role Collections**.
2. Find the role collection for `Editor` (created automatically from `xs-security.json`).
3. Click it → **Users** tab → **Assign User** → enter your BTP email.

Wait 1-2 minutes for the assignment to propagate, then log out and back in.

---

## Verifying the live app end-to-end

```bash
# Check all apps are running
cf apps
# All should show "started"

# Tail the logs if something is wrong
cf logs myapp-srv --recent

# Confirm the CAP API is reachable (replace with your actual URL)
curl https://myapp-srv.cfapps.eu10.hana.ondemand.com/api/Tasks
```

Open the approuter URL in a browser. You should see the XSUAA login page. Log in with your BTP credentials. The app loads and shows your seeded tasks.

---

## What you've learned across this course

| Episodes | Skills gained |
|---|---|
| 1–4 | SAPUI5 components, views, models, routing, fragments |
| 5–6 | CAP data modelling, OData generation, SQLite persistence |
| 7–9 | Connecting UI5 to CAP, full-stack CRUD, server-side value help |
| 10–11 | Validation, search, filter, sort |
| 12–15 | XSUAA auth, destinations, approuter, Cloud Foundry deployment |
| 16–19 | Design, build, polish, and deploy a complete app from scratch |

You now have a working deployed SAP BTP application with a real HANA database, secured by XSUAA, built on the modern CAP + UI5 stack used in production SAP projects.

---

## Common mistakes

**Mistake:** `cf deploy` succeeds but opening the app URL shows a blank page.
**Fix:** Check `cf logs myapp-approuter --recent`. A common cause is a misconfigured `xs-app.json` route — the `service: html5-apps-repo-rt` route must match the HTML5 app technical name.

**Mistake:** Role collection exists but access is still denied after assigning it.
**Fix:** Log out and log back in to get a new JWT token that includes the new scopes. Tokens are cached for their full lifetime.

**Mistake:** HANA database deployer fails with "quota exceeded".
**Fix:** Delete unused HDI container instances in BTP Cockpit → Services → Instances. Trial accounts are limited to a small number.

**Mistake:** App works in dev but gives 404 for `/backend/api/Tasks` in production.
**Fix:** Verify the destination `cap-backend` in BTP Cockpit points to the correct `myapp-srv` URL. Check for trailing slashes — `https://host.com/api/` with a trailing slash in the manifest but without one in the destination causes 404.

---

## ✅ Final Checkpoint

- [ ] Open the approuter URL in a browser — XSUAA login page appears.
- [ ] Log in — the app loads and shows your data.
- [ ] Create a new record — it persists after a page refresh.
- [ ] Edit a record — changes survive a refresh.
- [ ] Delete a record — it is gone after refresh.
- [ ] Log in with a Viewer-only account — write operations return 403.
- [ ] `cf apps` shows all four modules as **started**.