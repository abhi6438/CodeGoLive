# Episode 15 — Deploying to SAP BTP

## What you'll build

Deploy your complete application — UI5 frontend, CAP backend, approuter, and all BTP services — to SAP BTP Cloud Foundry using the **Multi-Target Application (MTA)** deployment model.

---

## Understanding mta.yaml

`mta.yaml` describes all the pieces of your application as a single deployable unit:

```yaml
_schema-version: "3.1"
ID: product-app
version: 1.0.0

modules:

  # ── CAP backend ────────────────────────────────────────────
  - name: product-app-srv
    type: nodejs
    path: .
    parameters:
      buildpack: nodejs_buildpack
      memory: 256M
    build-parameters:
      builder: npm
      build-result: gen/srv
      requires:
        - artifacts:
          - product-app-db-deployer.zip
          target-path: gen/db
    requires:
      - name: product-app-db
      - name: product-app-xsuaa

  # ── Database deployer (runs once to create tables + seed) ──
  - name: product-app-db-deployer
    type: hdb
    path: gen/db
    requires:
      - name: product-app-db
        properties:
          hdi-service-name: ${service-name}

  # ── Approuter ──────────────────────────────────────────────
  - name: product-app-approuter
    type: approuter.nodejs
    path: approuter
    parameters:
      memory: 128M
    requires:
      - name: product-app-xsuaa
      - name: product-app-html5-repo-runtime
      - name: srv-api
        group: destinations
        properties:
          name: cap-backend
          url: ~{srv-url}
          forwardAuthToken: true

  # ── UI5 app (deployed to HTML5 Repo) ──────────────────────
  - name: product-app-ui
    type: html5
    path: webapp
    build-parameters:
      build-result: dist
      builder: custom
      commands:
        - npm install
        - npm run build

resources:

  - name: product-app-db
    type: com.sap.xs.hdi-container
    parameters:
      service: hana
      service-plan: hdi-shared

  - name: product-app-xsuaa
    type: org.cloudfoundry.managed-service
    parameters:
      service: xsuaa
      service-plan: application
      config:
        xsappname: product-app
        tenant-mode: dedicated
        path: xs-security.json

  - name: product-app-html5-repo-runtime
    type: org.cloudfoundry.managed-service
    parameters:
      service: html5-apps-repo
      service-plan: app-runtime
```

---

## Step 1 — Build the CAP service for production

```bash
# Install the MTA build tool globally (once)
npm install -g mbt

# Build all modules defined in mta.yaml
mbt build

# Output: creates mta_archives/product-app_1.0.0.mtar
```

The `.mtar` file is a zip archive containing all built modules.

---

## Step 2 — Deploy to BTP

```bash
# Install the CF CLI and MTA plugin (once)
cf install-plugin multiapps

# Log in to BTP Cloud Foundry
cf login -a https://api.cf.eu10.hana.ondemand.com

# Deploy
cf deploy mta_archives/product-app_1.0.0.mtar
```

Watch the output — each module deploys sequentially. The database deployer runs first (creates tables, loads seed data), then the CAP service, then the approuter.

---

## Step 3 — Verify the deployment

```bash
# List running apps
cf apps

# Check logs if something failed
cf logs product-app-srv --recent
cf logs product-app-approuter --recent
```

Open the approuter URL (shown in `cf apps` output under `urls`). Your app should load and show the product list from the HANA database.

---

## Troubleshooting failed deployments

| Symptom | Likely cause | Fix |
|---|---|---|
| `product-app-db-deployer` fails | HANA HDI container not created | Check service plan availability in your BTP account |
| `product-app-srv` crashes on start | Missing environment variable | Check `cf env product-app-srv` for missing bindings |
| Approuter returns 502 | CAP service not started yet | Wait 2 minutes, then retry. Check `cf logs product-app-srv --recent` |
| Login loop after deploy | XSUAA redirect URI mismatch | Add the approuter URL to the XSUAA `redirect-uris` in `xs-security.json` and redeploy |
| Data missing after deploy | DB deployer ran but CSV not found | Check CSV files are in `db/data/` and the filename matches the entity namespace |

---

## Common mistakes

**Mistake:** `mbt build` fails with "module not found".
**Fix:** Run `npm install` in every module folder (root, `approuter/`) before running `mbt build`.

**Mistake:** Deployment succeeds but the app returns 404 for all API calls.
**Fix:** The `forwardAuthToken: true` property on the destination is required when CAP has XSUAA auth. Also check that the destination name in `xs-app.json` matches exactly.

**Mistake:** HANA service creation fails — "quota exceeded".
**Fix:** BTP trial accounts have limited HANA HDI containers. Delete unused ones in the BTP Cockpit under Services → Instances.

**Mistake:** After redeployment, old data persists when it shouldn't.
**Fix:** The database deployer does not drop and recreate tables by default (to preserve production data). To force a full redeploy of the schema, delete the HDI container instance and recreate it, then redeploy.

---

## ✅ Checkpoint

After `cf deploy`:
1. `cf apps` shows all three apps (`product-app-srv`, `product-app-approuter`, `product-app-ui`) with status **started**.
2. Opening the approuter URL in a browser shows the XSUAA login page (or the app directly if already logged in).
3. After logging in, the product list loads from the HANA database.
4. Creating a new product through the UI persists after a page refresh.