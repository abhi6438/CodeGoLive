# Episode 6 — SQLite Persistence: Real Data That Survives Restarts

## What you'll build

Upgrade your CAP service from an in-memory store to a **SQLite file database**. Add seed data via CSV files. After this episode, data persists between server restarts and you can inspect it with a SQL tool.

---

## Why SQLite for local dev?

| In-memory (Episode 5) | SQLite file (Episode 6) |
|---|---|
| Data lost on restart | Data persists in a `.db` file |
| No seed data needed (it is always empty) | Seed data loaded once from CSV |
| Good for: testing schemas | Good for: realistic local development |

In production (Episode 15) you use SAP HANA. The switch is one line in your deployment config — your CDS model and service code do not change at all.

---

## Project structure changes

```
6-sqllite-test/
 ├── db/
 │   ├── schema.cds
 │   └── data/                          ← NEW: CSV seed files live here
 │       ├── com.demo-Products.csv      ← one CSV per entity
 │       └── com.demo-Categories.csv
 ├── srv/
 │   └── product-service.cds
 ├── package.json                       ← update db kind
 └── .cdsrc.json                        ← optional: move db config here
```

---

## Step 1 — Update package.json to use a file database

Change the `cds.requires.db` section:

```json
{
  "cds": {
    "requires": {
      "db": {
        "kind": "sqlite",
        "credentials": {
          "database": "db/demo.db"
        }
      }
    }
  }
}
```

This tells CAP to store data in `db/demo.db`. The file is created automatically on first deploy.

---

## Step 2 — Deploy the schema to SQLite

```bash
cds deploy --to sqlite:db/demo.db
```

This command:
1. Reads your CDS schema files.
2. Generates the SQL `CREATE TABLE` statements.
3. Runs them against `db/demo.db`.
4. Loads any CSV files from `db/data/`.

You should see output like:

```
 > filling com.demo.Products from db/data/com.demo-Products.csv
 > filling com.demo.Categories from db/data/com.demo-Categories.csv
```

---

## Step 3 — Create CSV seed files

The filename format is critical: `<namespace>-<EntityName>.csv`

```
// db/data/com.demo-Products.csv

ID,name,category_ID,price
1,Laptop Pro 15,1,1299.00
2,Wireless Mouse,2,29.00
3,USB-C Hub 7-in-1,2,49.00
4,4K Monitor 27,1,599.00
5,Mechanical Keyboard,2,129.00
```

```
// db/data/com.demo-Categories.csv

ID,name
1,Electronics
2,Accessories
3,Software
```

**Important:** The column names in the CSV must match the CDS entity field names exactly (case-sensitive).

---

## Step 4 — Update the CDS schema to add Categories

```cds
// db/schema.cds

namespace com.demo;

entity Categories {
  key ID   : Integer;
      name : String(50);
}

entity Products {
  key ID       : Integer;
      name     : String(100);
      category : Association to Categories;
      price    : Decimal(10, 2);
}
```

An `Association to Categories` creates a foreign key `category_ID` automatically. In the CSV, use `category_ID` (the generated FK column name).

---

## Step 5 — Run and verify

```bash
cds watch
```

Now open `http://localhost:4004/api/Products` — you should see your 5 products as JSON.

To expand the association (join the category name):

```
http://localhost:4004/api/Products?$expand=category
```

Response includes the full category object nested inside each product.

---

## How CAP handles SQL without you writing any

When you write `Association to Categories`, CAP:
1. Creates a `category_ID` foreign key column in the Products table.
2. Generates `JOIN` queries automatically when you use `$expand`.
3. Enforces referential integrity at the database level.

You never write `SELECT p.*, c.name FROM Products p JOIN Categories c ON p.category_ID = c.ID`. CAP does it.

---

## Inspecting the SQLite file directly

```bash
# Install the sqlite3 CLI if not present
npm install -g sqlite3   # or: apt-get install sqlite3

# Open the database
sqlite3 db/demo.db

# Inside the sqlite shell:
.tables                    # list all tables
SELECT * FROM com_demo_Products;
SELECT * FROM com_demo_Categories;
.quit
```

Table names use underscores instead of dots: `com.demo.Products` → `com_demo_Products`.

---

## The difference between `:memory:` and a file

| `:memory:` | `db/demo.db` |
|---|---|
| Created fresh on every start | Persists between restarts |
| Seed data loaded from CSV on every start | Seed data loaded once (on `cds deploy`) |
| Re-deploy not needed | Run `cds deploy` after schema changes |

When you change your CDS schema (add a field, rename something), run `cds deploy` again to update the SQLite table structure.

---

## Common mistakes

**Mistake:** CSV data does not load — `cds deploy` output shows no "filling" lines.
**Fix:** Check the filename exactly: `com.demo-Products.csv` (namespace dot entity name, separated by a dash). The namespace comes from your CDS `namespace` declaration.

**Mistake:** `/api/Products` still returns empty after switching to file DB.
**Fix:** You may have forgotten to run `cds deploy`. The file database needs the schema deployed first. Run `cds deploy --to sqlite:db/demo.db`.

**Mistake:** Foreign key errors when loading CSV.
**Fix:** Load the referenced entity first. In the CSV for Products, the `category_ID` values must exist in the Categories CSV. CAP loads CSVs alphabetically — rename them with a number prefix (e.g. `1-com.demo-Categories.csv`, `2-com.demo-Products.csv`) to control order.

**Mistake:** After changing schema, old columns cause errors.
**Fix:** Delete `db/demo.db` and run `cds deploy` again. SQLite does not support all `ALTER TABLE` operations automatically.

---

## ✅ Checkpoint

After `cds deploy` then `cds watch`:
- `http://localhost:4004/api/Products` returns 5 products.
- `http://localhost:4004/api/Products?$expand=category` returns products with nested category objects.
- Restart the server (`Ctrl+C` then `cds watch`) — data is still there.