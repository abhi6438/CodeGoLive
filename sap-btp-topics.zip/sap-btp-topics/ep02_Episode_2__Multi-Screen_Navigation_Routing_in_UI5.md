# Episode 2 — Multi-Screen Navigation: Routing in UI5

## What you'll build

A two-screen SAPUI5 app: a **List page** showing all products, and a **Detail page** showing one product's full information. Tapping an item on the list navigates to its detail. The back button returns to the list.

---

## Why this matters

Almost every real business app has master-detail navigation. UI5's Router handles this cleanly: it maps URL hash fragments (like `#/product/P002`) to views, so navigation is bookmarkable and the browser back button works for free.

---

## The mental model: Router + Routes + Targets

```
User taps item
  → controller calls router.navTo("detail", { productId: "P002" })
    → URL changes to #/detail/P002
      → Router reads manifest.json routes config
        → finds the route matching "detail/:productId"
          → loads and displays the Detail view
            → Detail view's onInit reads productId from the URL and binds the view
```

Three things to configure in manifest.json: **routes** (URL patterns), **targets** (which view to show), and **routing** (which control to put views into).

---

## Project structure

```
2-ms-test/
 ├── webapp/
 │   ├── controller/
 │   │   ├── Main.controller.js     ← list page, handles tap + navigate
 │   │   └── Detail.controller.js   ← detail page, reads route params
 │   ├── view/
 │   │   ├── Main.view.xml          ← list of products
 │   │   └── Detail.view.xml        ← single product detail
 │   ├── model/
 │   │   └── data.json
 │   ├── Component.js
 │   ├── index.html
 │   └── manifest.json
 └── package.json
```

---

## File: webapp/manifest.json (routing section)

The routing config lives inside `sap.ui5`. This is the most important thing to get right.

```json
{
  "sap.ui5": {
    "rootView": {
      "viewName": "sap.ui.demo.ms.view.Main",
      "type": "XML",
      "async": true,
      "id": "app"
    },
    "routing": {
      "config": {
        "routerClass": "sap.m.routing.Router",
        "viewType": "XML",
        "viewPath": "sap.ui.demo.ms.view",
        "controlId": "app",
        "controlAggregation": "pages",
        "async": true
      },
      "routes": [
        {
          "name": "list",
          "pattern": "",
          "target": "list"
        },
        {
          "name": "detail",
          "pattern": "detail/{productId}",
          "target": "detail"
        }
      ],
      "targets": {
        "list": {
          "viewName": "Main",
          "viewLevel": 1
        },
        "detail": {
          "viewName": "Detail",
          "viewLevel": 2
        }
      }
    }
  }
}
```

**Key lines explained:**
- `"controlId": "app"` — the Router puts views into the `<App id="app">` control in the root view.
- `"controlAggregation": "pages"` — specifically into the `pages` aggregation of the App control.
- `"pattern": "detail/{productId}"` — `{productId}` is a URL parameter. It becomes available in the controller as a route argument.
- `"viewLevel"` — controls the slide animation direction. Higher level slides in from the right (forward). Lower level slides from the left (back).

---

## File: webapp/Component.js

Initialize the router in `init()` — this is required.

```js
sap.ui.define([
  "sap/ui/core/UIComponent",
  "sap/ui/model/json/JSONModel"
], function (UIComponent, JSONModel) {
  "use strict";

  return UIComponent.extend("sap.ui.demo.ms.Component", {
    metadata: { manifest: "json" },

    init: function () {
      UIComponent.prototype.init.apply(this, arguments);

      // Load data model
      var oModel = new JSONModel(
        sap.ui.require.toUrl("sap/ui/demo/ms/model/data.json")
      );
      this.setModel(oModel);

      // Initialize the router — reads routes from manifest.json
      // Without this line, navigation never works
      this.getRouter().initialize();
    }
  });
});
```

---

## File: webapp/view/Main.view.xml

The list page. Each item is tappable and passes the product id when pressed.

```xml
<mvc:View
  controllerName="sap.ui.demo.ms.controller.Main"
  xmlns:mvc="sap.ui.core.mvc"
  xmlns="sap.m"
  displayBlock="true">

  <Page title="Products">
    <content>
      <List
        id="productList"
        items="{/products}"
        mode="SingleSelectMaster">
        <StandardListItem
          title="{name}"
          description="{category}"
          info="{price} EUR"
          type="Navigation"
          press="onItemPress" />
      </List>
    </content>
  </Page>

</mvc:View>
```

**Note:** `type="Navigation"` renders the right-arrow chevron on each item, signaling to the user that tapping navigates somewhere.

---

## File: webapp/controller/Main.controller.js

Reads the tapped item's binding context to get its ID, then navigates.

```js
sap.ui.define([
  "sap/ui/core/mvc/Controller"
], function (Controller) {
  "use strict";

  return Controller.extend("sap.ui.demo.ms.controller.Main", {

    onInit: function () {
      // Nothing needed here — model is set in Component.js
    },

    onItemPress: function (oEvent) {
      // Get the binding context of the tapped list item
      // oContext.getPath() returns something like "/products/2"
      var oContext = oEvent.getSource().getBindingContext();
      var sPath = oContext.getPath();               // e.g. "/products/2"
      var oProduct = oContext.getObject();          // the full product object

      // Navigate to the detail route, passing the product id in the URL
      this.getOwnerComponent().getRouter().navTo("detail", {
        productId: oProduct.id   // becomes the {productId} URL parameter
      });
    }

  });
});
```

---

## File: webapp/view/Detail.view.xml

The detail page. Shows all fields of a single product. The `id="detailPage"` is used by the controller to bind data.

```xml
<mvc:View
  controllerName="sap.ui.demo.ms.controller.Detail"
  xmlns:mvc="sap.ui.core.mvc"
  xmlns="sap.m"
  displayBlock="true">

  <Page
    id="detailPage"
    title="{name}"
    showNavButton="true"
    navButtonPress="onNavBack">

    <content>
      <VBox class="sapUiMediumMargin">
        <ObjectHeader
          title="{name}"
          number="{price}"
          numberUnit="EUR" />

        <SimpleForm>
          <Label text="Product ID" />
          <Text text="{id}" />

          <Label text="Category" />
          <Text text="{category}" />

          <Label text="Price" />
          <Text text="{price} EUR" />
        </SimpleForm>
      </VBox>
    </content>

  </Page>

</mvc:View>
```

---

## File: webapp/controller/Detail.controller.js

Listens for the route match event, reads the URL parameter, and binds the view to the correct product.

```js
sap.ui.define([
  "sap/ui/core/mvc/Controller",
  "sap/ui/core/routing/History"
], function (Controller, History) {
  "use strict";

  return Controller.extend("sap.ui.demo.ms.controller.Detail", {

    onInit: function () {
      // Attach a handler that fires every time this route is navigated to
      var oRouter = this.getOwnerComponent().getRouter();
      oRouter.getRoute("detail").attachPatternMatched(this._onRouteMatched, this);
    },

    _onRouteMatched: function (oEvent) {
      // Read the productId from the URL (set by navTo in Main.controller.js)
      var sProductId = oEvent.getParameter("arguments").productId;

      // Find the index of this product in the model array
      var oModel = this.getOwnerComponent().getModel();
      var aProducts = oModel.getProperty("/products");
      var iIndex = aProducts.findIndex(function (p) {
        return p.id === sProductId;
      });

      if (iIndex === -1) {
        // Product not found — go back
        this.onNavBack();
        return;
      }

      // Bind the entire page to the product at this path
      // All {name}, {price}, {category} bindings in the view now resolve
      var oPage = this.byId("detailPage");
      oPage.bindElement("/products/" + iIndex);
    },

    onNavBack: function () {
      // Use History to go back to previous page, or fall back to list route
      var oHistory = History.getInstance();
      var sPreviousHash = oHistory.getPreviousHash();

      if (sPreviousHash !== undefined) {
        window.history.go(-1);
      } else {
        this.getOwnerComponent().getRouter().navTo("list", {}, true);
      }
    }

  });
});
```

**Key lines explained:**
- `attachPatternMatched` — fires every time the user navigates to this route, including back-and-forth. Use this instead of `onInit` for route-dependent setup.
- `bindElement("/products/2")` — sets the binding context for the entire page. Every `{name}`, `{price}` etc. in the view resolves relative to this path.
- `History.getInstance().getPreviousHash()` — checks if there is browser history to go back to. If the user opened the detail URL directly, there is no back history, so navigate to the list route explicitly.

---

## Common mistakes

**Mistake:** Tapping an item does nothing — no navigation.
**Fix:** Check that `this.getOwnerComponent().getRouter().initialize()` is called in `Component.js init()`. Without it the router never starts.

**Mistake:** Detail page is blank — no data shows.
**Fix:** Verify `bindElement` path. Add `console.log("/products/" + iIndex)` to confirm the index is correct before binding.

**Mistake:** The back button navigates to a blank page.
**Fix:** Make sure the root view's `<App id="app">` matches `"controlId": "app"` in manifest.json routing config. The Router puts pages into this control — if the id doesn't match, it creates a new hidden App.

**Mistake:** `attachPatternMatched` fires but `arguments.productId` is undefined.
**Fix:** The route pattern in manifest.json must use `{productId}` (with curly braces) and the `navTo` call must pass `productId` as a key in the parameters object.

---

## ✅ Checkpoint

Run `npm start`. You should be able to:
1. See a list of products on the main page.
2. Tap any product — the app slides to a detail page showing that product's full info.
3. Press the back button (top-left) — it slides back to the list.
4. The browser URL changes to `#/detail/P001` (or whichever id) on navigation.