# Episode 14 — The Approuter: Authentication Gateway

## What you'll build

Add the **SAP Approuter** to your project. The approuter sits in front of your UI5 app and CAP backend, handles the OAuth2 login flow with XSUAA, attaches JWT tokens to backend requests, and manages user sessions.

---

## What the approuter does

```
Browser
  │
  ▼
Approuter  ─── reads xs-app.json
  │
  ├── GET /  → serves the UI5 app HTML from html5-apps-repo
  │
  └── GET /backend/api/* → forwards to CAP with JWT token in Authorization header
              │
              ▼
         CAP validates token, checks scopes, returns data
```

Without the approuter, your UI5 app runs but has no authentication — anyone can call the API. With the approuter, unauthenticated users are redirected to the XSUAA login page.

---

## Step 1 — Create the approuter package

```
approuter/
 ├── xs-app.json      ← routing rules (from Episode 13)
 ├── package.json     ← approuter dependency
 └── default-env.json ← local config (never commit to git)
```

```json
// approuter/package.json
{
  "name": "approuter",
  "version": "1.0.0",
  "dependencies": {
    "@sap/approuter": "^14.0.0"
  },
  "scripts": {
    "start": "node node_modules/@sap/approuter/approuter.js"
  }
}
```

```bash
cd approuter
npm install
```

---

## Step 2 — Update xs-app.json (full version)

```json
{
  "authenticationMethod": "route",
  "sessionTimeout": 30,
  "routes": [
    {
      "source": "^/backend/(.*)$",
      "target": "/$1",
      "destination": "cap-backend",
      "authenticationType": "xsuaa",
      "csrfProtection": false
    },
    {
      "source": "^/(.*)$",
      "target": "$1",
      "service": "html5-apps-repo-rt",
      "authenticationType": "xsuaa"
    }
  ]
}
```

---

## Step 3 — Bind XSUAA in mta.yaml

The `mta.yaml` file describes your multi-target application for deployment. The approuter module must be bound to XSUAA:

```yaml
# mta.yaml (relevant sections)
modules:
  - name: approuter
    type: approuter.nodejs
    path: approuter
    requires:
      - name: xsuaa-service
      - name: cap-backend-destination
      - name: html5-repo-runtime

resources:
  - name: xsuaa-service
    type: org.cloudfoundry.managed-service
    parameters:
      service: xsuaa
      service-plan: application
      config:
        xsappname: product-app
        tenant-mode: dedicated
        path: xs-security.json
```

---

## Step 4 — Local testing with the approuter

For local testing, create `approuter/default-env.json` (never commit):

```json
{
  "PORT": 5000,
  "destinations": [
    {
      "name": "cap-backend",
      "url": "http://localhost:4004",
      "forwardAuthToken": false
    }
  ],
  "VCAP_SERVICES": {
    "xsuaa": [{
      "label": "xsuaa",
      "credentials": {
        "clientid": "sb-product-app",
        "clientsecret": "your-secret",
        "url": "https://your-tenant.authentication.eu10.hana.ondemand.com",
        "xsappname": "product-app"
      }
    }]
  }
}
```

For fully local testing without a real XSUAA, use CAP's mocked auth (Episode 12) and test the UI directly without the approuter.

---

## How token forwarding works

```
1. User opens the app in a browser
2. Approuter checks for a valid session cookie
   → No session: redirect to XSUAA login page
3. User enters credentials on XSUAA login page
4. XSUAA redirects back to the approuter with an authorization code
5. Approuter exchanges the code for a JWT token
6. Approuter stores the token in an encrypted session cookie
7. Approuter serves the UI5 HTML to the browser
8. Browser calls /backend/api/Products
9. Approuter reads the JWT from the session
   → Adds "Authorization: Bearer <token>" header
   → Forwards the request to the CAP service URL (from destination)
10. CAP validates the token and checks scopes
```

---

## Session vs token

| Session cookie | JWT token |
|---|---|
| Lives in the browser, managed by approuter | Sent in the `Authorization` header to the backend |
| Contains an encrypted reference to the JWT | Contains user info and scopes as plain JSON |
| Expires based on `sessionTimeout` in xs-app.json | Expires based on XSUAA settings (typically 12h) |
| Revokable by the approuter | Not revokable (validate expiry only) |

---

## Common mistakes

**Mistake:** After login, the app redirects in a loop and never loads.
**Fix:** The XSUAA redirect URI must be set to the approuter's URL. In the XSUAA service instance, the `oauth2-configuration.redirect-uris` must include `https://your-approuter-url.cfapps.eu10.hana.ondemand.com/**`.

**Mistake:** The approuter starts but all backend requests return 401.
**Fix:** Check that `"forwardAuthToken": true` is set on the destination in `default-env.json` (or in the BTP Destination config in production) when the backend requires the token.

**Mistake:** Session expires too quickly during development.
**Fix:** Increase `sessionTimeout` in `xs-app.json` (value is in minutes). Default is 15 minutes.

**Mistake:** `npm start` in the approuter fails with "Cannot find module '@sap/approuter'".
**Fix:** Run `npm install` inside the `approuter/` folder specifically, not in the project root.

---

## ✅ Checkpoint

1. Run the approuter locally (`npm start` in the `approuter/` folder) pointing to CAP on port 4004.
2. Open `http://localhost:5000` in a browser.
3. With mocked auth: you are logged in as the default mock user automatically.
4. The product list loads, routed through the approuter to CAP.
5. Check the CAP terminal — requests now show an `Authorization` header.