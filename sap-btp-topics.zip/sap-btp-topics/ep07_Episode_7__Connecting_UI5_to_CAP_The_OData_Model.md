# Episode 7 — Connecting UI5 to CAP: The OData Model

## What you'll build

Wire your Episode 1 single-screen UI5 app to your Episode 6 CAP backend. The product list now loads from the real OData API instead of a local JSON file. This is the moment the two halves of the stack connect.

---

## The key insight

An `ODataModel V4` in UI5 behaves almost identically to a `JSONModel` from the binding side. The list binding `items="{/Products}"` and the item binding `{name}` work the same. What changes is where the data comes from and how it gets there.

| JSONModel | ODataModel V4 |
|---|---|
| Reads from a local `.json` file | Reads from an OData service over HTTP |
| All data loaded at once | Loaded page-by-page on demand |
| Changes are local only | Changes sent to server as PATCH/POST/DELETE |
| No server round-trip | Every read/write is an HTTP request |

---

## Project structure changes

Only 3 files need updating:
1. `manifest.json` — add the OData data source and model
2. `Component.js` — remove the JSONModel, use the OData model from manifest
3. `ui5.yaml` — add a proxy so the UI5 dev server forwards `/api` requests to CAP

---

## Step 1 — Update manifest.json

```json
{
  "sap.app": {
    "id": "sap.ui.demo.ss",
    "dataSources": {
      "mainService": {
        "uri": "/api/",
        "type": "OData",
        "settings": {
          "odataVersion": "4.0"
        }
      }
    }
  },
  "sap.ui5": {
    "models": {
      "": {
        "dataSource": "mainService",
        "preload": true,
        "settings": {
          "synchronizationMode": "None",
          "operationMode": "Server",
          "autoExpandSelect": true
        }
      }
    }
  }
}
```

**Key changes:**
- `dataSources.mainService.uri: "/api/"` — the OData service URL. The `/api/` path is proxied to CAP by the dev server config.
- Declaring the model in manifest.json means UI5 creates it automatically. You no longer need to create it in `Component.js`.
- `"operationMode": "Server"` — sorting and filtering are done by the server (OData `$orderby`, `$filter`), not in the browser.

---

## Step 2 — Update Component.js

Remove the JSONModel code. UI5 now handles model creation from the manifest declaration.

```js
sap.ui.define([
  "sap/ui/core/UIComponent"
], function (UIComponent) {
  "use strict";

  return UIComponent.extend("sap.ui.demo.ss.Component", {
    metadata: { manifest: "json" },

    init: function () {
      UIComponent.prototype.init.apply(this, arguments);
      // No manual model creation needed.
      // UI5 reads the "models" section in manifest.json and creates the ODataModel.
      this.getRouter().initialize();
    }
  });
});
```

---

## Step 3 — Update the view binding path

OData entity names are PascalCase. Change `/products` to `/Products` in the list binding.

```xml
<List
  id="productList"
  items="{
    path: '/Products',
    parameters: {
      $select: 'ID,name,category_ID,price',
      $expand: 'category'
    }
  }">
  <StandardListItem
    title="{name}"
    description="{category/name}"
    info="{price} EUR"
    type="Navigation"
    press="onItemPress" />
</List>
```

**Key changes:**
- `/Products` (capital P) — OData entity set names match the CDS entity name.
- `$expand: 'category'` — fetches the associated Category record in the same request.
- `{category/name}` — navigates the association to get the category name.

---

## Step 4 — Configure the proxy (local dev only)

The UI5 dev server runs on port 5173 (or 8080). The CAP server runs on 4004. The browser cannot call `localhost:4004` directly from a page on `localhost:5173` due to CORS. A dev proxy fixes this.

```yaml
# ui5.yaml
specVersion: "3.0"
metadata:
  name: 7-cap-ss-test
type: application
server:
  customMiddleware:
    - name: ui5-middleware-simpleproxy
      afterMiddleware: compression
      mountPath: /api
      configuration:
        baseUri: http://localhost:4004/api
```

Install the proxy middleware:

```bash
npm install --save-dev ui5-middleware-simpleproxy
```

Now any request from the UI5 app to `/api/...` is forwarded to `http://localhost:4004/api/...`.

---

## OData V4 vs V2

You may see older UI5 code using `sap.ui.model.odata.v2.ODataModel`. This course uses V4:

| OData V2 | OData V4 |
|---|---|
| Older, more widespread in SAP systems | Modern standard, used by CAP |
| Two-phase commit (submitChanges) | Batch and auto-submit via binding |
| `$metadata` format is XML | Same XML, but richer type system |
| `sap.ui.model.odata.v2.ODataModel` | `sap.ui.model.odata.v4.ODataModel` |

CAP always generates OData V4. If you see tutorials using V2 they are based on older SAP Gateway services.

---

## Common mistakes

**Mistake:** List is blank and the console shows "CORS" errors.
**Fix:** The proxy is not set up correctly. Check `ui5.yaml` — the `mountPath` must be `/api` and `baseUri` must point to `http://localhost:4004/api`.

**Mistake:** OData model loads but list shows `undefined` for all fields.
**Fix:** OData entity property names are case-sensitive. Use the exact names from your CDS schema: `name`, `price`, `category`.

**Mistake:** `$expand=category` returns nothing.
**Fix:** You may have forgotten to run `cds deploy` after adding the Association in Episode 6. The SQLite schema needs to include the foreign key.

**Mistake:** App works in dev but the proxy stops working after restart.
**Fix:** Both CAP (`cds watch`) and the UI5 dev server (`npm start`) must be running simultaneously. Open two terminal tabs.

---

## ✅ Checkpoint

Start both servers:
```bash
# Terminal 1: CAP backend
cd 5-cap-1-test && cds watch

# Terminal 2: UI5 frontend
cd 7-cap-ss-test && npm start
```

Open `http://localhost:8080`. You should see the product list populated from CAP. The browser network tab should show a request to `/api/Products` returning your seeded data.