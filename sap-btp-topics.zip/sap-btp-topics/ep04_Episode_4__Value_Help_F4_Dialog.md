# Episode 4 — Value Help (F4) Dialog

## What you'll build

An input field that opens a searchable **Value Help dialog** (also called an F4 dialog, after the keyboard shortcut in SAP GUI) when the user clicks the value help icon. The user picks a value from the dialog and it fills the input field automatically.

---

## Why this matters

In enterprise apps, users should never type freeform text into fields that have a fixed set of valid values. A Value Help dialog shows the allowed values in a searchable list and prevents invalid input. This pattern is in nearly every SAP UI5 app you will build.

---

## The pattern in three parts

```
1. An Input control in your view with valueHelpRequest handler
       ↓
2. A SelectDialog fragment that lists the valid values
       ↓
3. A controller that opens the dialog, filters it on search,
   and writes the selected value back to the input
```

---

## Project structure

```
4-f4-test/
 ├── webapp/
 │   ├── controller/
 │   │   └── Main.controller.js
 │   ├── view/
 │   │   └── Main.view.xml
 │   ├── fragments/
 │   │   └── CategoryDialog.fragment.xml
 │   ├── model/
 │   │   └── data.json
 │   ├── Component.js
 │   ├── index.html
 │   └── manifest.json
 └── package.json
```

---

## File: webapp/model/data.json

Two lists: the products being edited, and the available categories for the value help.

```json
{
  "products": [
    { "id": "P001", "name": "Laptop Pro 15", "category": "Electronics" }
  ],
  "categories": [
    { "key": "Electronics", "text": "Electronics" },
    { "key": "Accessories", "text": "Accessories" },
    { "key": "Software",    "text": "Software" },
    { "key": "Furniture",   "text": "Furniture" },
    { "key": "Stationery",  "text": "Stationery" }
  ]
}
```

---

## File: webapp/view/Main.view.xml

The main form. The Category input has a value help icon (`showValueHelpIcon="true"`) and fires `valueHelpRequest` when clicked.

```xml
<mvc:View
  controllerName="sap.ui.demo.f4.controller.Main"
  xmlns:mvc="sap.ui.core.mvc"
  xmlns="sap.m"
  displayBlock="true">

  <Page title="Product Form">
    <content>
      <SimpleForm
        id="productForm"
        editable="true"
        layout="ResponsiveGridLayout"
        class="sapUiMediumMargin">

        <Label text="Product Name" />
        <Input
          id="inputName"
          value="{/products/0/name}"
          placeholder="Enter product name" />

        <Label text="Category" />
        <Input
          id="inputCategory"
          value="{/products/0/category}"
          showValueHelpIcon="true"
          valueHelpRequest="onCategoryValueHelp"
          placeholder="Click icon to choose category" />

      </SimpleForm>
    </content>
  </Page>

</mvc:View>
```

**Key attribute:** `valueHelpRequest="onCategoryValueHelp"` fires when the user clicks the F4 icon (the small icon at the right of the input). `showValueHelpIcon="true"` makes that icon visible.

---

## File: webapp/fragments/CategoryDialog.fragment.xml

The value help dialog. `SelectDialog` is a UI5 control specifically designed for this use case — it has built-in search and single/multi selection.

```xml
<core:FragmentDefinition
  xmlns="sap.m"
  xmlns:core="sap.ui.core">

  <SelectDialog
    id="categoryDialog"
    title="Select Category"
    search="onDialogSearch"
    confirm="onDialogConfirm"
    cancel="onDialogCancel"
    items="{
      path: '/categories',
      sorter: { path: 'text', descending: false }
    }">

    <StandardListItem
      title="{text}"
      description="{key}"
      type="Active" />

  </SelectDialog>

</core:FragmentDefinition>
```

**Key attributes:**
- `search` — fires as the user types in the search box. Your controller filters the list.
- `confirm` — fires when the user selects an item and presses OK.
- `cancel` — fires when the user closes without selecting.

---

## File: webapp/controller/Main.controller.js

```js
sap.ui.define([
  "sap/ui/core/mvc/Controller",
  "sap/ui/model/Filter",
  "sap/ui/model/FilterOperator"
], function (Controller, Filter, FilterOperator) {
  "use strict";

  return Controller.extend("sap.ui.demo.f4.controller.Main", {

    // ─── Open the dialog ──────────────────────────────────────────────────────

    onCategoryValueHelp: function () {
      // Load the fragment once and cache it
      if (!this._oCategoryDialog) {
        this._oCategoryDialog = this.loadFragment({
          name: "sap.ui.demo.f4.fragments.CategoryDialog"
        });
      }

      Promise.resolve(this._oCategoryDialog).then(function (oDialog) {
        this._oCategoryDialog = oDialog;

        // Reset any previous search filter before opening
        var oBinding = oDialog.getBinding("items");
        if (oBinding) {
          oBinding.filter([]);
        }

        oDialog.open();
      }.bind(this));
    },

    // ─── Search inside the dialog ─────────────────────────────────────────────

    onDialogSearch: function (oEvent) {
      var sValue = oEvent.getParameter("value");
      // Filter the categories list on the 'text' property
      var oFilter = new Filter("text", FilterOperator.Contains, sValue);
      var oBinding = oEvent.getSource().getBinding("items");
      oBinding.filter([oFilter]);
    },

    // ─── Confirm: write selected value back to the input field ───────────────

    onDialogConfirm: function (oEvent) {
      var oSelectedItem = oEvent.getParameter("selectedItem");
      if (oSelectedItem) {
        // Get the selected category key
        var sKey = oSelectedItem.getDescription(); // we put key in description

        // Write it back to the model — the Input binding updates automatically
        this.getView().getModel().setProperty("/products/0/category", sKey);
      }
      // Clear the search filter when dialog closes
      oEvent.getSource().getBinding("items").filter([]);
    },

    // ─── Cancel: just close ───────────────────────────────────────────────────

    onDialogCancel: function (oEvent) {
      oEvent.getSource().getBinding("items").filter([]);
    }

  });
});
```

---

## Understanding `loadFragment` vs the old pattern

| Old (before UI5 1.93) | New (UI5 1.93+) |
|---|---|
| `sap.ui.xmlfragment(viewId, fragmentName, controller)` | `this.loadFragment({ name: fragmentName })` |
| Returns the control synchronously | Returns a Promise |
| You must manually manage the fragment's lifecycle | The framework ties the fragment to the view lifecycle |

Always use `this.loadFragment` in modern UI5. It automatically calls `addDependent(fragment)` on the view, which means the fragment is destroyed when the view is destroyed — no memory leaks.

---

## Why `addDependent` matters

Without `addDependent`, the dialog lives outside the view's lifecycle. If the user navigates away and back, the dialog may keep old binding state or accumulate event handlers. When you use `this.loadFragment`, this is handled for you automatically.

---

## Common mistakes

**Mistake:** The dialog opens but the list is empty.
**Fix:** Check the binding path in the fragment — `path: '/categories'` uses the default model. If your model is named (e.g. `"data"`), use `path: 'data>/categories'`.

**Mistake:** After searching and confirming, the next time you open the dialog the search filter is still applied.
**Fix:** Always call `oBinding.filter([])` both in `onDialogConfirm` and `onDialogCancel`. Also reset it when the dialog opens (as shown in `onCategoryValueHelp`).

**Mistake:** `this.loadFragment` is undefined.
**Fix:** You are using a UI5 version older than 1.93. Use the old `sap.ui.xmlfragment` approach or upgrade your UI5 version in `index.html`.

**Mistake:** The value in the input does not update after confirming.
**Fix:** Check that your `setProperty` path exactly matches the binding in the view. If the input binds to `/products/0/category`, your `setProperty` must target the same path.

**Mistake:** The dialog shows but search does nothing.
**Fix:** The `Filter` property must match a real property in your data. `new Filter("text", ...)` filters on the `text` field. If your data uses `name` or `label`, update the filter accordingly.

---

## ✅ Checkpoint

Run `npm start`. You should see:
1. A form with a Product Name input and a Category input.
2. Clicking the icon on the Category input opens a dialog with 5 categories.
3. Typing in the search box filters the list in real time.
4. Selecting a category and pressing OK fills the Category input.
5. Pressing Cancel closes the dialog without changing the input.