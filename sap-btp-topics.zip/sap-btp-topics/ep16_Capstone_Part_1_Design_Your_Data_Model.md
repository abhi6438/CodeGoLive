# Capstone Part 1 — Design Your Data Model

## What you'll build

Design and implement the CDS data model for your own mini-project. By the end of this part you will have a running CAP backend with seeded data that you can query from a browser.

---

## Why design first?

A data model that changes halfway through a project causes cascading rewrites — the service, the UI, the CSV files, the OData bindings. Spending 30 minutes on the model design now saves hours later.

The design process is the same whether you are building a task tracker, an inventory system, or a leave management tool.

---

## How to design a CDS data model

Answer four questions before writing any code:

**1. What are my main entities?**
Things you need to store. Nouns: Product, Order, Employee, Project, Task, Customer.

**2. What are the relationships?**
One-to-many (a Project has many Tasks), many-to-many (a Task can have many Tags).

**3. What properties does each entity need?**
Only the fields you will actually display or filter on. Start minimal.

**4. What is the primary key?**
Use `UUID` for new records (CAP generates it automatically). Use a meaningful `String` key when the ID has business meaning (e.g. product codes like `P001`).

---

## Example: Task Tracker domain

```cds
// db/schema.cds

namespace com.tasker;

entity Projects {
  key ID          : UUID @Core.Computed;
      name        : String(100)  @mandatory;
      description : String(500);
      status      : String(20) default 'Active';
      createdAt   : DateTime @cds.on.insert: $now;
}

entity Tasks {
  key ID          : UUID @Core.Computed;
      title       : String(200)  @mandatory;
      description : String(1000);
      priority    : String(10) default 'Medium';  // Low / Medium / High
      dueDate     : Date;
      completed   : Boolean default false;
      project     : Association to Projects;       // FK: project_ID
      assignee    : String(100);
}
```

**Annotations explained:**
- `@Core.Computed` — CAP generates the UUID value; callers do not provide it.
- `@mandatory` — generates a NOT NULL constraint and an OData required annotation.
- `@cds.on.insert: $now` — CAP fills this with the current timestamp on INSERT.
- `Association to Projects` — creates a `project_ID` FK column automatically.

---

## Your service definition

```cds
// srv/task-service.cds

using com.tasker from '../db/schema';

service TaskService @(path: '/api') {

  entity Projects as projection on com.tasker.Projects
    actions {
      action archive() returns Projects;
    };

  entity Tasks as projection on com.tasker.Tasks;
}
```

The `actions` block lets you add custom business operations (like archiving a project) that go beyond basic CRUD.

---

## Deploy to SQLite and seed test data

```bash
# Create CSV seed files first (see the format below), then:
cds deploy --to sqlite:db/tasker.db
cds watch
```

```
// db/data/com.tasker-Projects.csv
ID,name,description,status
550e8400-e29b-41d4-a716-446655440000,Website Redesign,Redesign the company website,Active
550e8400-e29b-41d4-a716-446655440001,Mobile App,Build the iOS and Android app,Active
```

```
// db/data/com.tasker-Tasks.csv
ID,title,priority,completed,project_ID,assignee
660e8400-e29b-41d4-a716-446655440000,Design wireframes,High,false,550e8400-e29b-41d4-a716-446655440000,Alice
660e8400-e29b-41d4-a716-446655440001,Set up CI/CD pipeline,Medium,false,550e8400-e29b-41d4-a716-446655440000,Bob
660e8400-e29b-41d4-a716-446655440002,Implement login screen,High,false,550e8400-e29b-41d4-a716-446655440001,Alice
```

For UUIDs in test data, use any valid UUID v4. You can generate them at [uuidgenerator.net](https://www.uuidgenerator.net/).

---

## Self-check before continuing

Before moving to Part 2, verify each of these in a browser:

| URL | Expected result |
|---|---|
| `http://localhost:4004/api/Projects` | Returns your seeded projects |
| `http://localhost:4004/api/Tasks` | Returns your seeded tasks |
| `http://localhost:4004/api/Tasks?$expand=project` | Tasks with nested project object |
| `http://localhost:4004/api/Tasks?$filter=completed eq false` | Only incomplete tasks |
| `http://localhost:4004/api/$metadata` | XML describing all entities and associations |

If any of these fail, fix them before building the UI.

---

## Choosing your own domain

If you are building something different from the task tracker example, here are starter models for common domains:

**Inventory / stock management:**
```cds
entity Warehouses { key ID: UUID; name: String; location: String; }
entity Items { key ID: UUID; sku: String; name: String; quantity: Integer; warehouse: Association to Warehouses; }
```

**Leave management:**
```cds
entity Employees { key ID: UUID; name: String; department: String; }
entity LeaveRequests { key ID: UUID; type: String; startDate: Date; endDate: Date; status: String default 'Pending'; employee: Association to Employees; }
```

**Sales orders:**
```cds
entity Customers { key ID: UUID; name: String; email: String; country: String; }
entity Orders { key ID: UUID; orderDate: DateTime @cds.on.insert: $now; total: Decimal; status: String; customer: Association to Customers; }
entity OrderItems { key ID: UUID; product: String; quantity: Integer; price: Decimal; order: Association to Orders; }
```

---

## Common mistakes

**Mistake:** UUID primary keys cause CSV loading to fail.
**Fix:** Make sure every UUID in your CSV is a valid UUID v4 format (8-4-4-4-12 hex characters). Invalid UUIDs cause a silent load failure.

**Mistake:** Association shows as `project_ID` in the API but you expected `project`.
**Fix:** This is correct OData V4 behaviour. The navigation property is `project` (for `$expand=project`) but the stored FK column is `project_ID`. Both exist — use `project_ID` when creating/updating, `project` when expanding.

**Mistake:** `cds deploy` runs but `cds watch` shows empty entities.
**Fix:** Run `cds deploy` from the project root, not from inside `db/`. The path `db/tasker.db` is relative to where you run the command.

---

## ✅ Checkpoint

- CAP is running with `cds watch`.
- All your entities return seeded data via the browser.
- `$expand` works for all associations.
- `$filter` works for at least one property.