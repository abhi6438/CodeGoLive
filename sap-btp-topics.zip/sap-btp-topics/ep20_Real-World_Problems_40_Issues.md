# Real-World Problems: 40 Issues Every SAP BTP Developer Faces

## About this topic

Every problem below was reported by real developers building on the SAP BTP stack. Each entry shows the exact symptom you see, why it happens, and the exact fix. Bookmark this page — you will hit at least 20 of these.

---

## Category 1 — SAPUI5 Binding and Model Problems

---

### Problem 1: List shows no data — binding is correct but list is empty

**Symptom:** You write `items="{/products}"`, the model is loaded, but the list renders zero items.

**Why it happens:** The most common cause is a missing leading slash. `{products}` is a relative path and resolves to nothing at the root level.

**Fix:**
```xml
<!-- Wrong -->
<List items="{products}">

<!-- Correct -->
<List items="{/products}">
```
Second check: open the browser Network tab. If the JSON request returned 200 but the array key is different from what you bound to (e.g. data is in `"items"` but you bound to `"/products"`), the list is also empty.

---

### Problem 2: Two-way binding does not update the model

**Symptom:** User types in an `Input` field but `oModel.getProperty("/name")` still returns the old value.

**Why it happens:** Default binding mode for `JSONModel` is `TwoWay`, but for `ODataModel V4` the default is `OneWay`.

**Fix for JSONModel:**
```js
// Explicitly set mode (usually not needed, JSONModel defaults to TwoWay)
var oModel = new JSONModel(data);
oModel.setDefaultBindingMode("TwoWay");
this.getView().setModel(oModel);
```
**Fix for ODataModel V4:** Use `setProperty` on the context to stage the change, then `submitBatch` to send it. Two-way automatic binding is not how V4 works.

---

### Problem 3: `{i18n>title}` shows the key instead of the translated text

**Symptom:** The page shows literal text `{i18n>title}` instead of "My App Title".

**Why it happens:** The i18n model is not registered or the properties file path is wrong.

**Fix:** In `manifest.json`:
```json
"sap.ui5": {
  "models": {
    "i18n": {
      "type": "sap.ui.model.resource.ResourceModel",
      "settings": {
        "bundleName": "sap.ui.demo.ss.i18n.i18n"
      }
    }
  }
}
```
The bundle name `sap.ui.demo.ss.i18n.i18n` maps to `webapp/i18n/i18n.properties`. The last `i18n` is the filename without the extension.

---

### Problem 4: `bindElement` renders blank — all fields show empty

**Symptom:** You call `oView.bindElement("/Products(1)")` but every `{name}`, `{price}` etc. shows nothing.

**Why it happens:** Either the path does not exist in the model, or for OData the data has not arrived yet when you try to read it.

**Fix:** Add the `dataReceived` event handler to check for errors:
```js
this.getView().bindElement({
  path: "/Products(1)",
  events: {
    dataReceived: function (oEvent) {
      var oData = oEvent.getParameter("data");
      if (!oData) {
        console.error("bindElement failed:", oEvent.getParameter("error"));
      }
    }
  }
});
```
For OData, also confirm the entity key format matches: integer key → `/Products(1)`, UUID key → `/Products(550e8400-e29b-41d4-a716-446655440000)`.

---

### Problem 5: Navigation to detail works but back button shows a blank page

**Symptom:** Tapping an item navigates to the detail view. Pressing the back button returns to the list, but the list is now empty.

**Why it happens:** The router placed the detail view into the App control's `pages` aggregation but did not re-render the list page because it was destroyed (happens when `clearHistory: true` or the page is not cached).

**Fix:** Set `viewCacheKey` in the route target in `manifest.json` to cache the view, or use `History` correctly:
```js
onNavBack: function () {
  var sHash = History.getInstance().getPreviousHash();
  if (sHash !== undefined) {
    window.history.go(-1);
  } else {
    // No history — navigate explicitly to list
    this.getOwnerComponent().getRouter().navTo("list", {}, true);
    // true = replace current URL, prevents adding to history
  }
}
```

---

## Category 2 — SAPUI5 Routing Problems

---

### Problem 6: Route pattern matched but `arguments` is undefined

**Symptom:** `oEvent.getParameter("arguments").productId` throws "Cannot read properties of undefined".

**Why it happens:** The route pattern in `manifest.json` uses `{productId}` but the `navTo` call passes a different key name.

**Fix:**
```json
// manifest.json route
{ "pattern": "detail/{productId}", "name": "detail" }
```
```js
// Controller navTo — key must EXACTLY match the pattern parameter name
this.getOwnerComponent().getRouter().navTo("detail", {
  productId: "P001"   // must be "productId", not "id" or "product_id"
});
```

---

### Problem 7: Router initialized but navigation never happens — URL does not change

**Symptom:** `navTo` is called, no error in console, but the view does not change and the URL hash stays the same.

**Why it happens:** `this.getOwnerComponent().getRouter().initialize()` was never called in `Component.js`.

**Fix:**
```js
// Component.js — init() MUST call initialize()
init: function () {
  UIComponent.prototype.init.apply(this, arguments);
  // ...models...
  this.getRouter().initialize(); // ← without this, router does nothing
}
```

---

### Problem 8: Navigating between the same route twice does not refresh the view

**Symptom:** User is on `/detail/P001`, taps back, then taps a different item. The detail page still shows P001 data.

**Why it happens:** `onInit` runs only once. The view is reused. The route matched handler is the correct place for data loading, but it was not wired up.

**Fix:** Use `attachPatternMatched`, not `onInit`, for all data-loading on routed views:
```js
onInit: function () {
  this.getOwnerComponent().getRouter()
    .getRoute("detail")
    .attachPatternMatched(this._onRouteMatched, this);
},
_onRouteMatched: function (oEvent) {
  var sId = oEvent.getParameter("arguments").productId;
  // load data for sId every time route is activated
}
```

---

## Category 3 — CAP Backend Problems

---

### Problem 9: `cds watch` shows no error but `/api/Products` returns 404

**Symptom:** Terminal shows "serving ProductService { path: '/api' }" but the browser gets 404.

**Why it happens:** The CDS service path ends with `/api` but you are calling `/api/Products` — this is correct. If it returns 404 the entity name is wrong.

**Fix:** OData entity names are PascalCase and match the CDS entity definition exactly. If your entity is `Products`, the URL is `/api/Products` not `/api/products`.

---

### Problem 10: CSV data does not load — `cds deploy` shows no "filling" lines

**Symptom:** Running `cds deploy` shows no output like "filling com.demo.Products from ...".

**Why it happens:** CSV filename does not match the entity's full name including namespace.

**Fix:** The filename must be `<namespace>-<EntityName>.csv`. If your CDS file says `namespace com.demo` and entity `Products`, the file must be `com.demo-Products.csv` — not `Products.csv` or `products.csv`.

---

### Problem 11: CAP returns 400 but `req.error()` is called with status 400

**Symptom:** You call `req.error(400, "Name is required")` but the HTTP response body is empty or shows a different message.

**Why it happens:** `req.error()` accumulates errors — it does not throw immediately. If your handler code continues after `req.error()` and makes an invalid operation, a different error may overwrite yours.

**Fix:**
```js
this.before('CREATE', 'Products', (req) => {
  if (!req.data.name) {
    req.error(400, 'Name is required');
    return; // ← must return explicitly, req.error does NOT stop execution
  }
  // More validation...
});
```

---

### Problem 12: SQLite schema changes break the server — "no such column" error

**Symptom:** You add a new field to a CDS entity and restart `cds watch`. The server crashes with "no such column: newField".

**Why it happens:** SQLite does not automatically migrate the existing `.db` file when the schema changes.

**Fix:**
```bash
# Delete the old database file
rm db/demo.db

# Redeploy the schema and seed data
cds deploy --to sqlite:db/demo.db

# Then restart
cds watch
```
In production (HANA), CAP's HDI deployer handles migrations automatically.

---

### Problem 13: `$expand` returns null instead of the nested object

**Symptom:** `/api/Products?$expand=category` returns `{ "category": null }` for some products.

**Why it happens:** The `category_ID` foreign key value in those rows does not match any ID in the Categories table.

**Fix:** Check your CSV data. Every `category_ID` in `Products.csv` must exist as a `ID` in `Categories.csv`. Fix the CSV and run `cds deploy` again.

---

### Problem 14: CAP auto-generated CRUD gives 405 Method Not Allowed on DELETE

**Symptom:** Your service exposes `entity Products`, but `DELETE /api/Products(1)` returns 405.

**Why it happens:** The service was annotated with `@readonly` somewhere, or the entity is defined as read-only in the projection.

**Fix:** Check your `.cds` service file:
```cds
// Wrong — @readonly blocks all write operations
@readonly
entity Products as projection on com.demo.Products;

// Correct — no @readonly if you want full CRUD
entity Products as projection on com.demo.Products;
```

---

## Category 4 — OData V4 Model Problems

---

### Problem 15: `submitBatch` resolves but the record is NOT saved

**Symptom:** `submitBatch("myGroup")` resolves the Promise with no error, but refreshing the page shows the old data.

**Why it happens:** The `setProperty` call targeted a path that is not part of the `updateGroupId` batch group, or the model was created with `groupId: "$direct"` which sends each change immediately (not via batch).

**Fix:** Ensure your `setProperty` uses the same group the model is configured for:
```js
// In the model declaration in manifest.json
"settings": {
  "updateGroupId": "myUpdateGroup"
}
// In the controller
oModel.setProperty(sPath + "/name", sValue, undefined, true);
// 4th argument true = use the model's updateGroupId
oModel.submitBatch("myUpdateGroup");
```

---

### Problem 16: List binding `create()` throws "Not implemented"

**Symptom:** `oBinding.create({...})` throws a "Not implemented" or "Method not supported" error.

**Why it happens:** The binding is an OData V2 binding (`sap.ui.model.odata.v2.ODataModel`), which does not support `binding.create()`. V2 uses `oModel.createEntry()`.

**Fix:** Verify you are using OData V4 in your manifest:
```json
"settings": {
  "odataVersion": "4.0"
}
```
The model class should be `sap.ui.model.odata.v4.ODataModel`, not V2.

---

### Problem 17: OData request goes to the wrong URL — shows `undefined/api/Products`

**Symptom:** Network tab shows the request URL as `undefined/api/Products` or `null/api/Products`.

**Why it happens:** The `dataSource.uri` in `manifest.json` is missing or the service URL was left empty.

**Fix:**
```json
"dataSources": {
  "mainService": {
    "uri": "/api/",
    "type": "OData",
    "settings": { "odataVersion": "4.0" }
  }
}
```
The `uri` must start with `/` (relative to the host). The dev proxy in `ui5.yaml` then maps `/api/` to `http://localhost:4004/api/`.

---

## Category 5 — CORS and Proxy Problems

---

### Problem 18: CORS error in the browser — "No 'Access-Control-Allow-Origin' header"

**Symptom:** Console shows `Cross-Origin Request Blocked: The Same Origin Policy disallows reading the remote resource at http://localhost:4004/api/Products`.

**Why it happens:** The UI5 dev server (port 8080 or 5173) calls the CAP server (port 4004) directly. Browsers block this cross-origin request.

**Fix:** Add the proxy middleware to `ui5.yaml`:
```yaml
server:
  customMiddleware:
    - name: ui5-middleware-simpleproxy
      afterMiddleware: compression
      mountPath: /api
      configuration:
        baseUri: http://localhost:4004/api
```
Install it: `npm install --save-dev ui5-middleware-simpleproxy`. Now the browser calls `/api/...` on the same port, and the proxy forwards it to CAP.

---

### Problem 19: Proxy is set up but still getting CORS errors after deployment

**Symptom:** Works locally with the proxy. After `cf deploy`, the app gets CORS errors.

**Why it happens:** The `ui5.yaml` proxy only works in local development (`npm start`). In production, the approuter handles routing. If the approuter is not configured, the CORS issue returns.

**Fix:** Make sure `xs-app.json` has a route for `/backend/*` pointing to the `cap-backend` destination, and the destination has the correct URL set in BTP Cockpit.

---

## Category 6 — Authentication and XSUAA Problems

---

### Problem 20: Login succeeds but the app shows 403 Forbidden

**Symptom:** XSUAA login works (redirects back to the app), but every API call returns 403.

**Why it happens:** The logged-in user's BTP account has not been assigned the required role collection.

**Fix:**
1. Go to BTP Cockpit → Security → Role Collections.
2. Find the role collection for your app (e.g. "ProductAdmin").
3. Click it → Users tab → Assign User → enter the BTP email address.
4. Log out and log back in (the JWT token needs to be refreshed to include the new roles).

---

### Problem 21: Dev space works but production returns 401 for all API calls

**Symptom:** Local dev with `cds watch` works fine. After deploying, all API calls return 401.

**Why it happens:** The approuter is not forwarding the JWT token to the CAP service. The `forwardAuthToken: true` property is missing on the destination.

**Fix:** In `mta.yaml`, the approuter's destination binding must have `forwardAuthToken: true`:
```yaml
- name: myapp-approuter
  requires:
    - name: srv-api
      group: destinations
      properties:
        name: cap-backend
        url: ~{srv-url}
        forwardAuthToken: true   # ← this line is critical
```

---

### Problem 22: After adding `@requires` to a CDS service, local development breaks completely

**Symptom:** You add `@requires: 'authenticated-user'` to your service. Now every local `cds watch` request returns 401.

**Why it happens:** The mocked auth is not configured, so CAP requires a real token even locally.

**Fix:** Add a `.cdsrc.json` with mock users:
```json
{
  "requires": {
    "auth": {
      "kind": "mocked",
      "users": {
        "alice": { "roles": ["ProductViewer", "ProductAdmin"] }
      }
    }
  }
}
```
Then use Basic auth in your requests: `curl -u alice:alice http://localhost:4004/api/Products`.

---

## Category 7 — Deployment Problems

---

### Problem 23: `mbt build` fails with "Cannot find module"

**Symptom:** Running `mbt build` exits with a Node "Cannot find module" error.

**Why it happens:** `npm install` was not run in one of the module subfolders (e.g. `approuter/`).

**Fix:**
```bash
npm install              # root
cd approuter && npm install && cd ..
cd webapp && npm install && cd ..
mbt build
```

---

### Problem 24: `cf deploy` succeeds but the app URL returns 502 Bad Gateway

**Symptom:** All modules show as "started" in `cf apps` but opening the approuter URL gives 502.

**Why it happens:** The CAP service started but crashed immediately after. The approuter cannot reach it.

**Fix:**
```bash
cf logs myapp-srv --recent
```
Read the CAP startup logs. Common causes:
- HANA HDI container not fully provisioned yet (wait 2 minutes, retry).
- A missing environment binding (check `cf env myapp-srv`).
- A code error in the service's `server.js` or event handlers.

---

### Problem 25: Data is missing after deployment — HANA tables are empty

**Symptom:** The app deploys and runs, but the product list is empty — seed data is not there.

**Why it happens:** The HDI deployer module ran before the HANA service was fully provisioned, or the CSV files were not included in the `gen/db` artifact.

**Fix:**
```bash
# Rebuild the db artifacts
cds build --production

# Check that gen/db/data/ contains your CSV files
ls gen/db/data/

# Redeploy just the db deployer module
cf deploy mta_archives/myapp_1.0.0.mtar --strategy rolling -m myapp-db-deployer
```

---

### Problem 26: Deployment fails with "quota exceeded" for HANA service

**Symptom:** `cf deploy` fails with "Service broker error: quota exceeded" when creating the HANA HDI container.

**Why it happens:** BTP trial accounts have a strict limit on the number of HANA HDI containers (typically 1).

**Fix:**
1. Go to BTP Cockpit → Services → Instances.
2. Delete any unused HDI container instances from previous projects.
3. Retry the deployment.

---

### Problem 27: App redirects in a login loop and never loads

**Symptom:** The app URL redirects to XSUAA login, login succeeds, then redirects back to the app, which immediately redirects to login again — infinite loop.

**Why it happens:** The XSUAA service's `redirect-uris` does not include the approuter URL.

**Fix:** In `xs-security.json`, add the approuter URL to the redirect URIs:
```json
{
  "oauth2-configuration": {
    "redirect-uris": [
      "https://myapp-approuter.cfapps.eu10.hana.ondemand.com/**"
    ]
  }
}
```
Redeploy after this change. The `**` wildcard allows any path under the domain.

---

## Category 8 — BAS (Business Application Studio) Problems

---

### Problem 28: BAS dev space is "STOPPED" and files appear to be gone

**Symptom:** You open BAS the next morning and the dev space shows "STOPPED". Clicking it starts it, but the file explorer seems empty.

**Why it happens:** BTP trial dev spaces auto-stop after 30-60 minutes of inactivity. Files are preserved — the space just needs to be restarted.

**Fix:** Click the ▶ play button next to the dev space name. Wait about 60 seconds. Your files are exactly where you left them. If the file tree still appears empty, press F5 to reload BAS.

---

### Problem 29: BAS terminal shows "npm: command not found"

**Symptom:** Opening a new terminal in BAS and typing `npm --version` returns "command not found".

**Why it happens:** The dev space is a "Basic" kind, not "SAP Fiori" kind. Basic dev spaces do not pre-install Node.js.

**Fix:** Delete the dev space and create a new one with kind **SAP Fiori**. This pre-installs Node.js, npm, the UI5 CLI, and the CAP CLI.

---

### Problem 30: `npm start` in BAS shows no preview — browser tab does not open

**Symptom:** `npm start` runs `ui5 serve` without errors but the "Open in New Tab" popup never appears.

**Why it happens:** The port mapping for the dev server did not register in BAS.

**Fix:** After `npm start`, look at the bottom status bar in BAS for a port indicator, or go to the **Ports** panel (View → Ports). Find the port (default 8080 for UI5), hover over it, and click the Globe icon to open it in a new tab.

---

### Problem 31: CDS language support shows red underlines but `cds watch` works fine

**Symptom:** BAS shows red squiggles under valid CDS syntax (entity definitions, annotations).

**Why it happens:** The CDS Language Support extension is not installed in this dev space.

**Fix:** In BAS, open the Extensions panel (Ctrl+Shift+X), search for "SAP CDS Language Support", and install it. Reload BAS after installation.

---

## Category 9 — UI5 Fragment and Dialog Problems

---

### Problem 32: Dialog opens with stale data the second time

**Symptom:** Dialog shows correct data the first time. After closing and reopening for a different item, it still shows the first item's data.

**Why it happens:** The dialog model is only set once. When you reopen the dialog, the old model is still there.

**Fix:** Set the model fresh every time the dialog opens:
```js
_openDialog: function (oNewModel) {
  Promise.resolve(this._oDialog).then(function (oDialog) {
    oDialog.setModel(oNewModel, "dialog"); // ← called every open, not just once
    oDialog.open();
  }.bind(this));
}
```

---

### Problem 33: `this.loadFragment` is not a function

**Symptom:** Controller throws "TypeError: this.loadFragment is not a function".

**Why it happens:** You are using UI5 version older than 1.93.

**Fix:** Use the old API as a fallback:
```js
// Old way (works on all versions)
this._oDialog = sap.ui.xmlfragment(
  this.getView().getId(),
  "com.myapp.fragments.MyDialog",
  this
);
this.getView().addDependent(this._oDialog);
this._oDialog.open();
```
Or update your UI5 version in `index.html` to 1.120+.

---

### Problem 34: Fragment loads but none of the button press handlers fire

**Symptom:** Dialog opens, buttons are visible, but clicking them does nothing — no errors, no function called.

**Why it happens:** The fragment was loaded without passing `this` (the controller) as the controller argument.

**Fix:**
```js
// Wrong — no controller context
sap.ui.xmlfragment("com.myapp.fragments.MyDialog");

// Correct — pass the controller as third argument
sap.ui.xmlfragment(
  this.getView().getId(),
  "com.myapp.fragments.MyDialog",
  this   // ← controller context
);
```
With `this.loadFragment`, the controller is always `this` automatically — no extra argument needed.

---

## Category 10 — Performance and Network Problems

---

### Problem 35: OData request returns all fields but the UI only uses two — network is slow

**Symptom:** `/api/Products` returns 50 fields per record but your list only shows `name` and `price`. Page is slow.

**Why it happens:** No `$select` is specified, so OData returns everything.

**Fix:** Add `$select` to the list binding:
```xml
<List items="{
  path: '/Products',
  parameters: {
    $select: 'ID,name,price'
  }
}">
```
This sends `GET /api/Products?$select=ID,name,price` — a fraction of the data.

---

### Problem 36: Scrolling the list makes dozens of HTTP requests

**Symptom:** Opening a product list triggers one request. Scrolling down triggers one request per row.

**Why it happens:** Lazy loading (`GrowingList` or `Table` with `growing="true"`) is enabled and the page size is set to 1 (or the threshold is very small).

**Fix:** Set a reasonable page size:
```xml
<List growing="true" growingThreshold="25">
```
This loads 25 items at a time, not 1. The default is 20 if you do not specify.

---

### Problem 37: App takes 10 seconds to load on first open

**Symptom:** The app loads instantly during development but takes 10+ seconds in production.

**Why it happens:** All UI5 resources are loaded individually in development mode. Production requires a build step to bundle them.

**Fix:**
```bash
# Build the UI5 app for production (bundles all JS/CSS into fewer files)
ui5 build --all

# Or via npm
npm run build
```
The `dist/` folder contains the optimized bundle. In `mta.yaml`, deploy from `dist/` not `webapp/`.

---

### Problem 38: Filter request returns all items — `$filter` is ignored by CAP

**Symptom:** Sending `/api/Products?$filter=contains(name,'lap')` returns all products unfiltered.

**Why it happens:** The service or entity is annotated with `@cds.query.limit` or `@cds.search` but the OData filter is being applied to the wrong field path.

**Fix:** Check the field name in the filter matches the CDS entity field name exactly (case-sensitive). `name` is different from `Name`. Also verify your CAP version supports the `contains()` OData function (requires CAP 6+).

---

## Category 11 — Data and Type Problems

---

### Problem 39: Price saves as a string `"29"` instead of number `29`

**Symptom:** After creating a product, the database stores `"29"` (string) for the price field instead of `29` (number). Sorting by price gives wrong results.

**Why it happens:** HTML input values are always strings. If you read the value with `getProperty()` or `getValue()` and pass it directly to the model without parsing, it stays a string.

**Fix:**
```js
// Wrong
req.data.price = this.byId("inputPrice").getValue();

// Correct
req.data.price = parseFloat(this.byId("inputPrice").getValue()) || 0;
```

---

### Problem 40: UUID primary keys cause "Cannot create record — key conflict" on second deploy

**Symptom:** After a schema redeploy, inserting records fails with a unique constraint violation.

**Why it happens:** Your CSV seed data uses hardcoded UUIDs. When you redeploy, CAP tries to insert the same UUIDs again. If the HDI deployer is configured to merge (not replace) data, duplicates fail.

**Fix Option 1:** Use integer keys for seed data (simpler, no UUID format required).

**Fix Option 2:** Add `--dry-run` to your deploy command to check what will happen before it runs.

**Fix Option 3:** For the HDI deployer in production, configure `undeploy.json` to drop and re-create the data on each deploy:
```json
["com.demo::Products"]
```
This tells HDI to delete and reseed the `Products` data on every deployment. Only use this for reference/lookup data, never for user-generated records.

---

## Quick troubleshooting lookup

| Symptom | Most likely cause | Jump to |
|---|---|---|
| List shows no items | Wrong binding path (missing `/`) | Problem 1 |
| Two-way binding not working | ODataModel V4 does not auto-sync | Problem 2 |
| i18n shows key text | i18n model not declared in manifest | Problem 3 |
| bindElement renders blank | Path wrong or data not arrived yet | Problem 4 |
| Back button shows blank page | View destroyed, not cached | Problem 5 |
| Route arguments undefined | navTo key != pattern parameter | Problem 6 |
| navTo does nothing | Router not initialized | Problem 7 |
| Detail shows wrong record | Using onInit instead of attachPatternMatched | Problem 8 |
| 404 on valid OData URL | Wrong entity case (Products vs products) | Problem 9 |
| CSV not loaded | Wrong filename format | Problem 10 |
| req.error continues execution | Forgot `return` after req.error | Problem 11 |
| "no such column" error | Schema changed, forgot cds deploy | Problem 12 |
| $expand returns null | FK value not found in parent table | Problem 13 |
| 405 on DELETE | @readonly annotation on entity | Problem 14 |
| submitBatch resolves but no save | Wrong updateGroupId | Problem 15 |
| oBinding.create throws | Using OData V2 not V4 | Problem 16 |
| URL shows undefined/api/... | dataSource uri missing in manifest | Problem 17 |
| CORS error in browser | Proxy not configured in ui5.yaml | Problem 18 |
| CORS in production | Approuter routes not configured | Problem 19 |
| 403 after login | Role collection not assigned to user | Problem 20 |
| 401 in production | forwardAuthToken missing | Problem 21 |
| Local dev 401 after @requires | Mocked auth not configured | Problem 22 |
| mbt build "Cannot find module" | npm install not run in subfolder | Problem 23 |
| 502 after deploy | CAP service crashed — check cf logs | Problem 24 |
| HANA tables empty | HDI deployer ran before HANA ready | Problem 25 |
| "quota exceeded" on deploy | Delete unused HDI container instances | Problem 26 |
| Infinite login redirect loop | XSUAA redirect-uris not set | Problem 27 |
| BAS dev space looks empty | Auto-stopped — restart it | Problem 28 |
| npm not found in BAS | Wrong dev space kind (needs SAP Fiori) | Problem 29 |
| Preview tab does not open | Open manually via Ports panel | Problem 30 |
| CDS red underlines | CDS Language Support not installed | Problem 31 |
| Dialog shows stale data | Model not reset on open | Problem 32 |
| loadFragment not a function | UI5 version < 1.93 | Problem 33 |
| Fragment buttons do nothing | Controller not passed to xmlfragment | Problem 34 |
| Slow network, too many fields | Missing $select on list binding | Problem 35 |
| Scroll triggers many requests | growingThreshold too small | Problem 36 |
| Slow production load | App not built (npm run build) | Problem 37 |
| $filter ignored | Field name case mismatch | Problem 38 |
| Price saves as string | Missing parseFloat() | Problem 39 |
| UUID key conflict on redeploy | Duplicate UUIDs in CSV | Problem 40 |