# Episode 11 — Search, Filter, and Sort

## What you'll build

A product list with a live **search bar** (filters by name), **category filter** (Select control), and a **sort button** that toggles ascending/descending by price. All filtering and sorting is done server-side via OData query options.

---

## The complete UI — SearchField + Sort button

```xml
<mvc:View
  controllerName="sap.ui.demo.filt.controller.Main"
  xmlns:mvc="sap.ui.core.mvc"
  xmlns="sap.m"
  displayBlock="true">

  <Page title="Products">

    <headerContent>
      <Button id="sortBtn" icon="sap-icon://sort" press="onSortPress"
              tooltip="Sort by price" />
    </headerContent>

    <subHeader>
      <Toolbar>
        <SearchField
          id="searchField"
          placeholder="Search by name..."
          search="onSearch"
          liveChange="onSearch"
          width="60%" />
        <ToolbarSpacer />
        <Select id="categoryFilter" change="onCategoryFilter">
          <core:Item key="" text="All Categories"
            xmlns:core="sap.ui.core" />
          <core:Item key="Electronics" text="Electronics"
            xmlns:core="sap.ui.core" />
          <core:Item key="Accessories" text="Accessories"
            xmlns:core="sap.ui.core" />
          <core:Item key="Software"    text="Software"
            xmlns:core="sap.ui.core" />
        </Select>
      </Toolbar>
    </subHeader>

    <content>
      <List id="productList" items="{/Products}">
        <StandardListItem
          title="{name}"
          description="{category/name}"
          info="{price} EUR" />
      </List>
    </content>

  </Page>

</mvc:View>
```

---

## Search handler

```js
sap.ui.define([
  "sap/ui/core/mvc/Controller",
  "sap/ui/model/Filter",
  "sap/ui/model/FilterOperator",
  "sap/ui/model/Sorter"
], function (Controller, Filter, FilterOperator, Sorter) {
  "use strict";

  return Controller.extend("sap.ui.demo.filt.controller.Main", {

    onInit: function () {
      // Track current sort state
      this._bSortDescending = false;
    },

    // Shared helper: read current filter/search values and apply all at once
    _applyFiltersAndSort: function () {
      var oList    = this.byId("productList");
      var oBinding = oList.getBinding("items");
      var aFilters = [];

      // 1. Search filter (by name)
      var sQuery = this.byId("searchField").getValue().trim();
      if (sQuery) {
        aFilters.push(new Filter("name", FilterOperator.Contains, sQuery));
      }

      // 2. Category filter
      var sCategoryKey = this.byId("categoryFilter").getSelectedKey();
      if (sCategoryKey) {
        aFilters.push(new Filter("category/name", FilterOperator.EQ, sCategoryKey));
      }

      // Apply: if multiple filters, AND them together
      var oCombinedFilter = aFilters.length > 1
        ? new Filter({ filters: aFilters, and: true })
        : (aFilters[0] || null);

      oBinding.filter(oCombinedFilter ? [oCombinedFilter] : []);
    },

    onSearch: function () {
      this._applyFiltersAndSort();
    },

    onCategoryFilter: function () {
      this._applyFiltersAndSort();
    },
```

---

## Sort handler — toggle ascending/descending

```js
    onSortPress: function () {
      // Toggle the sort direction each press
      this._bSortDescending = !this._bSortDescending;

      var oList    = this.byId("productList");
      var oBinding = oList.getBinding("items");

      var oSorter = new Sorter("price", this._bSortDescending);
      oBinding.sort(oSorter);

      // Update button icon to show current direction
      var oBtn = this.byId("sortBtn");
      oBtn.setIcon(this._bSortDescending
        ? "sap-icon://sort-descending"
        : "sap-icon://sort-ascending");
    },

  }); // end controller
});
```

`new Sorter("price", true)` tells UI5 to send `$orderby=price desc` in the OData request. CAP translates this to SQL `ORDER BY price DESC`.

---

## Multi-column sort

To sort by multiple fields (e.g. category then price):

```js
var aSorters = [
  new Sorter("category/name", false),   // primary: category ascending
  new Sorter("price", true)             // secondary: price descending
];
oBinding.sort(aSorters);
// Sends: $orderby=category/name asc,price desc
```

---

## Combining filter + sort

Calling `oBinding.filter(...)` and `oBinding.sort(...)` separately works but causes two HTTP requests. To send one request:

```js
// OData V4 ListBinding supports chaining:
oBinding.changeParameters({});  // forces a refresh with current filter AND sort combined
```

Or — the recommended way — always call both together in `_applyFiltersAndSort`:

```js
_applyFiltersAndSort: function () {
  var oBinding = this.byId("productList").getBinding("items");
  // ... build aFilters as above ...
  oBinding.filter(oCombinedFilter ? [oCombinedFilter] : []);

  var oSorter = new Sorter("price", this._bSortDescending);
  oBinding.sort(oSorter);
  // UI5 V4 ODataListBinding batches these into one GET request
},
```

---

## FilterBar for advanced multi-field search

For enterprise forms with many filter fields, use `sap.ui.comp.filterbar.FilterBar`:

```xml
<!-- Requires sap.ui.comp library -->
<filterBar:FilterBar
  id="filterBar"
  search="onFilterBarSearch"
  xmlns:filterBar="sap.ui.comp.filterbar">
  <filterBar:filterGroupItems>
    <filterBar:FilterGroupItem name="name" label="Name" visibleInFilterBar="true">
      <filterBar:control>
        <Input id="filterName" />
      </filterBar:control>
    </filterBar:FilterGroupItem>
  </filterBar:filterGroupItems>
</filterBar:FilterBar>
```

For this course, the `SearchField` + `Select` approach covers the common case.

---

## Common mistakes

**Mistake:** Search works but category filter does nothing.
**Fix:** The category filter path `"category/name"` navigates an association. Make sure `$expand=category` is in the list binding parameters so the association data is available.

**Mistake:** Filter sends the request but results are wrong — "Electronics" filter returns all items.
**Fix:** The `FilterOperator.EQ` comparison is case-sensitive by default in OData. Ensure your seed data uses the exact same casing as your filter value.

**Mistake:** Typing in the search field causes a new HTTP request on every keystroke.
**Fix:** Use `search` event (fires on Enter or clear) instead of `liveChange`, or debounce `liveChange`:
```js
onSearchLive: function (oEvent) {
  clearTimeout(this._searchTimer);
  this._searchTimer = setTimeout(function () {
    this._applyFiltersAndSort();
  }.bind(this), 300); // wait 300ms after last keystroke
},
```

**Mistake:** Sort button press throws "sort is not a function".
**Fix:** OData V4 list bindings use `.sort()`. OData V2 bindings use `.sort()` too but with a different Sorter API. Confirm your model is OData V4 (`sap.ui.model.odata.v4.ODataModel`).

---

## ✅ Checkpoint

1. Open the product list. All products show.
2. Type "lap" in the search bar — only products with "lap" in the name appear.
3. Select "Electronics" from the dropdown — the list further filters.
4. Click the Sort button — list re-orders by price ascending. Click again — descending.
5. Clear the search and reset the filter — all products return.