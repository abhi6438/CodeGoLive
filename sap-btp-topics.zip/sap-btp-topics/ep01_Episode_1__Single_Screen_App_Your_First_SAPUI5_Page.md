# Episode 1 — Single Screen App: Your First SAPUI5 Page

## What you'll build

A single-screen SAPUI5 app that loads a product list from a local JSON file and displays it in a Fiori List. No backend, no routing yet — just the fundamentals of how UI5 boots, binds data, and renders.

---

## Why this matters

Every SAPUI5 app — no matter how complex — is built on three things: a **Component** (the app entry point), a **View** (the XML layout), and a **Model** (the data). Get this triangle right now and every later episode clicks into place.

---

## How UI5 boots — the sequence

Understanding this sequence prevents 80% of beginner errors:

```
index.html loads the UI5 bootstrap script
  → UI5 sees <div data-sap-ui-component> in the body
    → UI5 reads Component.js (named by data-name attribute)
      → Component.js creates a JSONModel and sets it on the app
        → Component.js reads manifest.json to find the root view
          → manifest.json points to webapp/view/Main.view.xml
            → Main.view.xml renders your list, bound to the model
```

Nothing magical. Just a chain of lookups based on naming conventions.

---

## Project structure

```
1-ss-test/
 ├── webapp/
 │   ├── controller/
 │   │   └── Main.controller.js
 │   ├── view/
 │   │   └── Main.view.xml
 │   ├── model/
 │   │   └── data.json
 │   ├── Component.js
 │   ├── index.html
 │   └── manifest.json
 └── package.json
```

---

## File: index.html

This is the only HTML file. It loads the UI5 framework and tells it where to find your app.

```html
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
  <title>1-SS-Test</title>
  <script id="sap-ui-bootstrap"
    src="https://sdk.openui5.org/1.120.0/resources/sap-ui-core.js"
    data-sap-ui-theme="sap_horizon"
    data-sap-ui-resourceroots='{"sap.ui.demo.ss": "./"}'
    data-sap-ui-compatVersion="edge"
    data-sap-ui-oninit="module:sap/ui/core/ComponentSupport"
    data-sap-ui-async="true">
  </script>
</head>
<body class="sapUiBody">
  <div data-sap-ui-component
    data-name="sap.ui.demo.ss"
    data-id="container"
    data-settings='{"id": "ss"}'>
  </div>
</body>
</html>
```

**Key lines explained:**
- `data-sap-ui-resourceroots` — maps the namespace `sap.ui.demo.ss` to the current folder `./`. UI5 uses this to find all your files.
- `data-sap-ui-oninit="module:sap/ui/core/ComponentSupport"` — tells UI5 to scan the body for a `<div data-sap-ui-component>` and boot it.
- `data-name="sap.ui.demo.ss"` — UI5 translates this to `sap/ui/demo/ss/Component.js` using the resourceroots map.

---

## File: webapp/Component.js

The app's entry point. Creates the JSON model and mounts it before the view renders.

```js
sap.ui.define([
  "sap/ui/core/UIComponent",
  "sap/ui/model/json/JSONModel"
], function (UIComponent, JSONModel) {
  "use strict";

  return UIComponent.extend("sap.ui.demo.ss.Component", {
    metadata: {
      manifest: "json"   // tells UI5 to read manifest.json for routing and view config
    },

    init: function () {
      // Always call the parent init first
      UIComponent.prototype.init.apply(this, arguments);

      // Load the JSON file and set it as the default (unnamed) model
      var oModel = new JSONModel(
        sap.ui.require.toUrl("sap/ui/demo/ss/model/data.json")
      );
      this.setModel(oModel);
      // Now any view in this app can bind to this model with {/...} paths
    }
  });
});
```

**Key lines explained:**
- `UIComponent.prototype.init.apply(this, arguments)` — never skip this. It sets up internal UI5 plumbing. Skipping it causes silent failures.
- `this.setModel(oModel)` with no name sets the **default model**. Views bind to it with paths starting with `/`.

---

## File: webapp/manifest.json

The app descriptor. Declares the app identity, root view, and registered models.

```json
{
  "_version": "1.58.0",
  "sap.app": {
    "id": "sap.ui.demo.ss",
    "type": "application",
    "title": "Single Screen App",
    "applicationVersion": { "version": "1.0.0" }
  },
  "sap.ui5": {
    "rootView": {
      "viewName": "sap.ui.demo.ss.view.Main",
      "type": "XML",
      "async": true,
      "id": "app"
    },
    "dependencies": {
      "minUI5Version": "1.120.0",
      "libs": { "sap.m": {}, "sap.ui.core": {} }
    }
  }
}
```

**Key lines explained:**
- `rootView.viewName` — UI5 translates `sap.ui.demo.ss.view.Main` to `webapp/view/Main.view.xml` using the resourceroots mapping.
- `"async": true` — loads the view asynchronously. Always use this in modern UI5.

---

## File: webapp/model/data.json

The data your list will display. Plain JSON — no server needed.

```json
{
  "products": [
    { "id": "P001", "name": "Laptop Pro 15",    "category": "Electronics", "price": 1299 },
    { "id": "P002", "name": "Wireless Mouse",    "category": "Accessories", "price":   29 },
    { "id": "P003", "name": "USB-C Hub 7-in-1",  "category": "Accessories", "price":   49 },
    { "id": "P004", "name": "4K Monitor 27\"",   "category": "Electronics", "price":  599 },
    { "id": "P005", "name": "Mechanical Keyboard","category": "Accessories", "price":  129 }
  ]
}
```

---

## File: webapp/view/Main.view.xml

The XML layout. Binds the List to the model array, and each list item to individual product properties.

```xml
<mvc:View
  controllerName="sap.ui.demo.ss.controller.Main"
  xmlns:mvc="sap.ui.core.mvc"
  xmlns="sap.m"
  displayBlock="true">

  <Shell>
    <App id="app">
      <pages>
        <Page title="Products">
          <content>
            <List
              id="productList"
              headerText="Product Catalogue"
              items="{/products}">
              <StandardListItem
                title="{name}"
                description="{category}"
                info="{price} EUR"
                infoState="Success"
                press="onItemPress"
                type="Active" />
            </List>
          </content>
        </Page>
      </pages>
    </App>
  </Shell>

</mvc:View>
```

**Key lines explained:**
- `items="{/products}"` — binds the list to the `products` array in the default model. UI5 creates one `StandardListItem` per array entry.
- `title="{name}"` — relative binding. Because the list is already bound to `/products`, each item's context is one product object. `{name}` means "the `name` property of this product".
- `press="onItemPress"` and `type="Active"` — makes items tappable. The controller handles the press event.

---

## File: webapp/controller/Main.controller.js

Handles user interaction. Shows a toast when an item is tapped.

```js
sap.ui.define([
  "sap/ui/core/mvc/Controller",
  "sap/m/MessageToast"
], function (Controller, MessageToast) {
  "use strict";

  return Controller.extend("sap.ui.demo.ss.controller.Main", {

    onInit: function () {
      // Called once when the view is created.
      // Nothing needed here yet — the model is set in Component.js.
    },

    onItemPress: function (oEvent) {
      // oEvent.getSource() returns the StandardListItem that was pressed
      var oItem = oEvent.getSource();
      var sName = oItem.getTitle();
      MessageToast.show("You selected: " + sName);
    }

  });
});
```

---

## File: package.json

Tells the UI5 CLI how to serve and build the app.

```json
{
  "name": "1-ss-test",
  "version": "1.0.0",
  "scripts": {
    "start": "ui5 serve",
    "build": "ui5 build --all"
  },
  "devDependencies": {
    "@ui5/cli": "^3.0.0"
  }
}
```

Run `npm install` once, then `npm start` to launch the dev server.

---

## Data binding quick reference

| Expression | What it means |
|---|---|
| `{/products}` | The root-level `products` array in the default model |
| `{name}` | The `name` property relative to the current list item context |
| `{/products/0/name}` | Absolute path to the first product's name |
| `{modelName>/path}` | A named model (not the default) |

---

## Common mistakes

**Mistake:** List shows no items.
**Fix:** Check the binding path. `{products}` (without `/`) is a relative path and resolves to nothing at the root. It must be `{/products}`.

**Mistake:** UI5 can't find the controller — console shows "Cannot load module".
**Fix:** The `controllerName` in the view (`sap.ui.demo.ss.controller.Main`) must match the string in the controller's `extend()` call exactly. Also verify `data-sap-ui-resourceroots` in index.html maps `sap.ui.demo.ss` to `./`.

**Mistake:** `data.json` returns 404.
**Fix:** Open the browser network tab. If the URL looks wrong, check that `sap.ui.require.toUrl("sap/ui/demo/ss/model/data.json")` resolves correctly — the slashes come from the namespace dots.

**Mistake:** Pressing an item does nothing.
**Fix:** Make sure the list item has both `type="Active"` and `press="onItemPress"`. Without `type="Active"` the item is not visually interactive.

---

## ✅ Checkpoint

Run `npm start`. In the browser you should see:
- A Fiori shell with a page titled "Products".
- A list of 5 items — each with a name, category, and price.
- Clicking any item shows a MessageToast at the bottom of the screen with the product name.