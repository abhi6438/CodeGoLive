# Episode 10 — Input Validation and User Feedback

## What you'll build

Three layers of validation on your product form: instant client-side guards in the controller, type-constraint validation via UI5 binding types, and server-side validation in CAP that returns structured error messages back to the UI.

---

## Three layers of validation

```
Layer 1: JS guard in the controller  ─── fast, no server round-trip
        ↓ (passes)
Layer 2: UI5 binding type constraint ─── validates format (email, date, number range)
        ↓ (passes)
Layer 3: CAP backend validation      ─── business rules, database constraints
```

Each layer catches different things. Never rely on only one layer — the browser-side can be bypassed, and the server-side gives a bad user experience if it is the first to catch a typo.

---

## Layer 1 — JS guard in the controller

A simple manual check before you even try to save:

```js
// In Detail.controller.js — onSavePress

onSavePress: function () {
  var sName  = this.byId("inputName").getValue().trim();
  var sPrice = this.byId("inputPrice").getValue();
  var nPrice = parseFloat(sPrice);

  // Check 1: name must not be empty
  if (!sName) {
    MessageBox.error("Product name cannot be empty.");
    this.byId("inputName").setValueState("Error");
    this.byId("inputName").setValueStateText("Name is required");
    return;   // stop here, don't save
  }

  // Check 2: price must be a positive number
  if (isNaN(nPrice) || nPrice <= 0) {
    MessageBox.error("Price must be a positive number.");
    this.byId("inputPrice").setValueState("Error");
    this.byId("inputPrice").setValueStateText("Enter a number greater than 0");
    return;
  }

  // All checks passed — clear error states and save
  this.byId("inputName").setValueState("None");
  this.byId("inputPrice").setValueState("None");
  this._saveProduct(sName, nPrice);
},
```

`setValueState("Error")` turns the input border red. `setValueStateText(...)` shows a tooltip explaining the error. `setValueState("None")` clears it.

---

## Layer 2 — Binding type constraints

Add type constraints directly in the view XML. UI5 validates these automatically when the user leaves the field (on `change` event):

```xml
<Input
  id="inputPrice"
  value="{
    path: 'form>/price',
    type: 'sap.ui.model.type.Float',
    constraints: {
      minimum: 0.01,
      maximum: 999999.99,
      minFractionDigits: 2,
      maxFractionDigits: 2
    },
    formatOptions: {
      minFractionDigits: 2
    }
  }"
  placeholder="0.00" />
```

When the user types `abc` or `-5`, UI5 automatically:
1. Shows the input in red (`ValueState: Error`).
2. Displays the constraint message as a tooltip.
3. Marks the binding as invalid so you can detect it before saving.

---

## Checking binding errors before saving

Before calling save, check if any bound control has a pending type error:

```js
_hasBindingErrors: function () {
  var oView = this.getView();
  // Check all inputs by their IDs
  var aInputIds = ["inputName", "inputPrice", "inputCategory"];
  return aInputIds.some(function (sId) {
    var oControl = oView.byId(sId);
    return oControl && oControl.getValueState() === "Error";
  });
},

onSavePress: function () {
  if (this._hasBindingErrors()) {
    MessageBox.error("Please fix the highlighted errors before saving.");
    return;
  }
  // ... proceed with save
},
```

---

## MessageToast vs MessageBox — when to use which

| Situation | Use |
|---|---|
| Non-blocking confirmation ("Saved successfully") | `MessageToast.show(text)` |
| Error that needs acknowledgement | `MessageBox.error(text)` |
| Confirmation before a destructive action (delete) | `MessageBox.confirm(text, { onClose: fn })` |
| Warning with multiple options | `MessageBox.warning(text, { actions: [...] })` |

```js
// MessageToast — disappears automatically after 3 seconds
MessageToast.show("Product saved");

// MessageBox.error — blocks UI until user clicks OK
MessageBox.error("Name is required", {
  title: "Validation Error",
  onClose: function () {
    // Optional: focus the failing input
    this.byId("inputName").focus();
  }.bind(this)
});

// MessageBox.confirm — ask before deleting
MessageBox.confirm("Delete this product permanently?", {
  title: "Confirm Delete",
  onClose: function (sAction) {
    if (sAction === MessageBox.Action.OK) {
      this._doDelete();
    }
  }.bind(this)
});
```

---

## CAP backend validation

Add input checks in the CAP service handler. `req.error()` sends a structured OData error response:

```js
// srv/product-service.js

this.before('CREATE', 'Products', (req) => {
  const { name, price, category_ID } = req.data;

  if (!name || name.trim().length === 0) {
    req.error(400, 'Product name is required', 'name');
  }
  if (!price || price <= 0) {
    req.error(400, 'Price must be greater than zero', 'price');
  }
  if (!category_ID) {
    req.error(400, 'Category is required', 'category_ID');
  }
});

this.before('UPDATE', 'Products', (req) => {
  if (req.data.price !== undefined && req.data.price <= 0) {
    req.error(400, 'Price must be greater than zero', 'price');
  }
});
```

The third argument to `req.error` is the **target field name**. OData clients can use this to highlight the specific failing input.

---

## Surface CAP errors in the UI

When `submitBatch` fails, the error comes back as a rejected Promise. Parse the message out and show it:

```js
oModel.submitBatch("myUpdateGroup")
  .then(function () {
    MessageToast.show("Saved");
  })
  .catch(function (oError) {
    // oError.message contains the CAP error text
    var sMsg = oError.message || "An unknown error occurred";

    // For OData batch errors, the detail is nested:
    if (oError.cause && oError.cause.responseText) {
      try {
        var oBody = JSON.parse(oError.cause.responseText);
        sMsg = oBody.error.message || sMsg;
      } catch (e) { /* ignore parse error */ }
    }

    MessageBox.error(sMsg);
  }.bind(this));
```

---

## Common mistakes

**Mistake:** `setValueState("Error")` shows red but the user can still save.
**Fix:** You must check `getValueState() === "Error"` (or use `_hasBindingErrors`) before proceeding with save. Setting the visual state does not automatically block the save.

**Mistake:** Type constraint in the binding fires but the error message is generic ("EnterNumber").
**Fix:** Add a `formatOptions.parseAsString: false` to ensure the type parser runs. Also add a custom `type` class extending `sap.ui.model.type.Float` to customise the message.

**Mistake:** CAP validation error arrives but the UI does not show it — console shows the error but the user sees nothing.
**Fix:** Wrap `submitBatch` in `.catch(...)`. The ODataModel does not automatically surface backend errors to the UI.

**Mistake:** `req.error(400, ...)` does not stop execution — code after it still runs.
**Fix:** `req.error` in CAP accumulates errors but does not throw. Add `return;` after each `req.error` call, or check `req.errors.length > 0` before continuing.

---

## ✅ Checkpoint

1. Try saving a product with an empty name — the name input turns red and a MessageBox appears.
2. Try entering a negative price — the price input turns red.
3. Fix both fields and save — the form saves successfully.
4. Use `curl` to send an invalid POST directly to CAP and verify it returns a 400 with a proper error message:
```bash
curl -X POST http://localhost:4004/api/Products \
  -H "Content-Type: application/json" \
  -d '{"name": "", "price": -1, "category_ID": 1}'
```