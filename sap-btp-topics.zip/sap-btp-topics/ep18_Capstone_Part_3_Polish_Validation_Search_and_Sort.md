# Capstone Part 3 — Polish: Validation, Search, and Sort

## What you'll build

Add the finishing touches that make your app feel professional: proper validation with visual error states, a working search bar, sortable columns, confirmation dialogs before destructive actions, an empty state when the list has no results, and a loading indicator.

---

## Polish checklist

Work through these in order — each one builds on the previous:

1. ☐ Validation on all required fields (controller guard + binding types)
2. ☐ CAP backend validation with error messages surfaced in the UI
3. ☐ Confirmation dialog before delete
4. ☐ Search on the list view
5. ☐ Sort on the list view
6. ☐ Empty state message when the list has no results
7. ☐ BusyIndicator while data is loading

---

## Validation pass — add to your Edit view controller

For each required field in your form, add both a visual guard and a binding type:

```js
_validateForm: function () {
  var bValid = true;

  // Check each required input
  var aRequired = [
    { id: "inputTitle",    label: "Title is required" },
    { id: "inputAssignee", label: "Assignee is required" }
  ];

  aRequired.forEach(function (oField) {
    var oInput = this.byId(oField.id);
    if (!oInput.getValue().trim()) {
      oInput.setValueState("Error");
      oInput.setValueStateText(oField.label);
      bValid = false;
    } else {
      oInput.setValueState("Success");
    }
  }.bind(this));

  return bValid;
},

onSavePress: function () {
  if (!this._validateForm()) {
    MessageToast.show("Please fix the highlighted fields");
    return;
  }
  // ... proceed with submitBatch
},
```

---

## Surface CAP errors in the UI

Wrap every `submitBatch` call in a `.catch`:

```js
oModel.submitBatch("saveGroup")
  .then(function () {
    MessageToast.show("Saved successfully");
    this.onNavBack();
  }.bind(this))
  .catch(function (oError) {
    var sMsg = "Save failed";
    try {
      // CAP OData errors are in error.cause.responseText
      var oBody = JSON.parse(oError.cause.responseText);
      sMsg = oBody.error.message || sMsg;
    } catch (e) { /* ignore */ }
    MessageBox.error(sMsg, { title: "Error" });
  });
```

---

## Confirmation before delete

Never delete without asking:

```js
onDeletePress: function () {
  var sItemName = this._oContext.getProperty("title") || "this item";

  MessageBox.confirm(
    "Are you sure you want to delete \"" + sItemName + "\"? This cannot be undone.",
    {
      title: "Confirm Delete",
      emphasizedAction: MessageBox.Action.OK,
      onClose: function (sAction) {
        if (sAction !== MessageBox.Action.OK) { return; }

        this._oContext.delete()
          .then(function () {
            MessageToast.show("Deleted");
            this.onNavBack();
          }.bind(this))
          .catch(function (oErr) {
            MessageBox.error("Delete failed: " + oErr.message);
          });
      }.bind(this)
    }
  );
},
```

---

## Search on the list view

```js
onSearch: function (oEvent) {
  var sQuery   = oEvent.getParameter("query") || oEvent.getParameter("newValue") || "";
  var oBinding = this.byId("mainList").getBinding("items");
  var aFilters = [];

  if (sQuery.trim()) {
    // Replace "title" with the main text field of your entity
    aFilters.push(new Filter("title", FilterOperator.Contains, sQuery.trim()));
  }

  oBinding.filter(aFilters);
},
```

In the view, set both `search` and `liveChange` on the SearchField so it responds to both Enter key and typing:

```xml
<SearchField
  id="searchField"
  search="onSearch"
  liveChange="onSearch"
  placeholder="Search tasks..." />
```

---

## Sort on the list view

Add a sort button in the page header or toolbar. Toggle between ascending and descending on each press:

```js
onSortPress: function () {
  this._bDesc = !this._bDesc;
  var oBinding = this.byId("mainList").getBinding("items");
  // Replace "title" with your sort field (e.g. "dueDate", "priority", "name")
  oBinding.sort(new Sorter("title", this._bDesc));

  this.byId("sortBtn").setIcon(this._bDesc
    ? "sap-icon://sort-descending"
    : "sap-icon://sort-ascending");
},
```

---

## Empty state

Show a helpful message when the filtered list has no results:

```xml
<List id="mainList" items="{/Tasks}" noDataText="No tasks found. Try a different search.">
  ...
</List>
```

For a richer empty state with an icon, use `IllustratedMessage` (requires `sap.f` library):

```xml
<f:IllustratedMessage
  illustrationType="sapIllus-NoData"
  title="No Tasks"
  description="Create your first task by pressing the + button."
  visible="{= ${/Tasks}.length === 0 }"
  xmlns:f="sap.f" />
```

---

## Loading state — BusyIndicator

Show a spinner while the OData request is in flight:

```js
// In onRouteMatched, before bindElement
this.getView().setBusy(true);

this.getView().bindElement({
  path: "/Tasks(" + sId + ")",
  parameters: { $expand: "project" },
  events: {
    dataReceived: function () {
      this.getView().setBusy(false);
    }.bind(this)
  }
});
```

`setBusy(true)` overlays the entire view with a semi-transparent spinner. `setBusy(false)` in the `dataReceived` event removes it.

---

## The finished feel

A polished app does these things automatically — the user never has to wonder:

| Situation | Polished behaviour |
|---|---|
| Saving a record | Busy spinner on button → success toast → navigate back |
| Validation error | Red input border + tooltip → MessageBox explanation |
| Deleting an item | Confirmation dialog → success toast → return to list |
| Empty search result | Friendly empty state with guidance |
| Data still loading | Subtle spinner — never a blank white page |

---

## Common mistakes

**Mistake:** `getParameter("query")` returns undefined.
**Fix:** `SearchField` `search` event uses `"query"`. The `liveChange` event uses `"newValue"`. Handle both: `var s = oEvent.getParameter("query") || oEvent.getParameter("newValue") || ""`.

**Mistake:** BusyIndicator never disappears.
**Fix:** Always call `setBusy(false)` in both `dataReceived` (success) and `dataRequested` error path. Use a `try/finally` pattern or attach to both events.

**Mistake:** Delete confirmation fires twice.
**Fix:** `MessageBox.confirm` callback may be bound twice if `onInit` runs more than once (e.g. view is recreated). Use `detachPatternMatched` and re-attach in `onInit`.

---

## ✅ Checkpoint

Go through the polish checklist at the top of this episode. Every item should have a checkmark before you move to Part 4.

Test these edge cases specifically:
- Try to save with an empty required field → should show error, not save.
- Delete an item → confirm the dialog appears.
- Type a search term that matches nothing → should show empty state, not a blank list.
- Navigate to the detail page → should show a loading spinner while data arrives.